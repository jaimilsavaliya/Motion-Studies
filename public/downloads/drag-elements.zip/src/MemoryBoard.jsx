import DragElements from './components/DragElements';

export default function MemoryBoard() {
  return <DragElements height={530} dragElastic={0.5}
    dragMomentum={false} selectedOnTop={true}
    dragTransition={{ bounceStiffness: 200, bounceDamping: 300 }}
    style={{ padding: 80, background: '#eeeeee', borderRadius: 16 }}>
    {['One lovely day', 'Wish you were here', 'Good times'].map((label, index) => (
      <div key={label} aria-label={label} style={{
        width: 160, padding: 20, background: 'white', color: '#171717',
        transform: 'rotate(' + (index * 5 - 5) + 'deg)',
        boxShadow: '0 20px 40px #0003',
      }}>{label}</div>
    ))}
  </DragElements>;
}
