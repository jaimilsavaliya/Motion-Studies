import { useRef } from 'react';
import DragElements from './components/DragElements';

export default function BoundedLabels() {
  const bounds = useRef(null);
  return <div ref={bounds} style={{ height: 400, background: '#1f464d', overflow: 'hidden' }}>
    <DragElements height="100%" dragConstraints={bounds}
      dragElastic={{ left: 0, right: 0.5, top: 0.2, bottom: 0.2 }}
      dragMomentum={true} style={{ padding: 80 }}>
      {['super fun', 'funky time!', 'awesome'].map(label => (
        <div key={label} aria-label={label} style={{ padding: '16px 28px',
          borderRadius: 100, background: '#e896dc', color: '#1f464d', fontSize: 32 }}>
          {label}
        </div>
      ))}
    </DragElements>
  </div>;
}

// Or constrain translation relative to each item's starting position:
// dragConstraints={{ left: -80, right: 180, top: -80, bottom: 150 }}
// Use draggable={false} on image and video children.
