# Drag Elements

Independent React + CSS implementation. React 18+, Pointer Events, ResizeObserver
and a CSS-capable bundler. No animation dependency, external service or paid registry.
Copy DragElements.jsx and DragElements.css into src/components.
MemoryBoard.jsx and BoundedLabels.jsx are self-contained examples without remote assets.
Demo photographs and the showcase font are intentionally excluded; bring licensed media.

## API
children: each direct child receives an independent, absolute-positioned wrapper.
  Give dynamic children stable keys. Child transforms/rotation stay intact.
height: 500 by default; pixels or a definite CSS height. style can override this.
style/className: root presentation. Padding controls the initial stack origin.
dragElastic: 0.5. Number 0–1, boolean (true=0.35/false=0), or per-side
  {left,right,top,bottom}. Omitted sides in an object use zero.
dragConstraints: defaults to the own container's inner bounds. Accepts an element ref
  or {left,right,top,bottom} translation limits relative to each starting position.
  Omitted object edges are unbounded. Oversized items pan between aligned edges.
dragMomentum: true. Photo examples disable it; label examples enable it.
dragTransition: {bounceStiffness:200,bounceDamping:300}; also supports power (0.8),
  timeConstant (750ms), restDelta (10px) and restSpeed (10px/s). Only these options
  are implemented; this is not a drop-in replacement for an animation-package API.
dragPropagation: true; false stops pointer-down propagation to ancestor wrappers.
selectedOnTop: true; selection/focus promotes a child above its siblings.
onDragEnd(index,{x,y}): once after a moved gesture, with release coordinates before settling.
aria-label: Draggable elements. Child aria-label/alt supplies the wrapper name.

Both release modes spring back from an elastic boundary. Momentum=false does not
coast inside the bounds. The default return is intentionally slow and overdamped.
Rotated child corners may escape the wrapper bounds. To clip elastic overshoot,
set overflow:hidden on an enclosing stage. Put your transforms on the child itself.

Keyboard: Tab to an item, arrows move 20px, Shift+arrows 80px, Home/Escape reset.
Reduced motion clamps immediately and disables release inertia. Native inputs,
editable content, media controls and data-drag-ignore descendants do not initiate
movement. Buttons can opt out with data-drag-ignore. Link taps still work, but actual
drags suppress accidental clicks. Use draggable={false} on images/videos. Pointer
capture handles outside release; cancellation and lost capture stop the gesture.
Resize clamps positions. Stable keys preserve positions on rerender/removal.
The animation loop runs only while something is settling. Listeners, observers
and the loop are cleaned up when unmounted. Each wrapper remains keyboard focusable.

Next.js App Router is supported by the use client directive. With Pages Router,
move the CSS import into pages/_app.jsx. The core inherits your font and colors.
