# Focus Scale Carousel

An independent React implementation inspired by https://useplanes.com/components/focus-scale-carousel.
No proprietary Planes source is included.

Copy FocusScaleCarousel.jsx and FocusScaleCarousel.css into the same folder in your React 18+ project.
Requires modern browser ResizeObserver, IntersectionObserver, pointer capture, and the Web Animations API.
No carousel framework or animation package is required.

Replace sample image paths with your own appropriately licensed assets. Reference photos are not included.

## Props
items: array of { src, title, collection?, alt?, objectPosition? }; default [].
cardWidth: 320px; clamped 120–500.
cardHeight: 430px; clamped 160–700.
gap: 14px; clamped 0–40.
neighborScale: .37; clamped .2–.8.
scaleDecay: .78; clamped .5–.95.
sideCount: 6; clamped 1–8.
duration: 850ms; clamped 200–1600.
autoPlay: 4000ms; zero disables, positive values clamped 1000–15000.
mobileScale: .55 below 640px container width; clamped .35–1.
radius: 2px; clamped 0–30.
showFrame: true.
showControls: true; supply a pause control when false.
paused: false; external autoplay pause without disabling manual navigation.
initialIndex: 0; read on mount, wrapped to the item count.
onIndexChange: optional (index, item) callback for selection changes, not initial mount.
className: optional root class.

Stage height is cardHeight + 88px at desktop defaults. Leave about 50px beneath it for the controls.
Click a neighbouring frame to select it. Swipe horizontally to advance roughly one item per 50px,
scaled on mobile and capped to sideCount steps. Short/cancelled gestures settle back.
Keyboard: focus the gallery, then Left/Right, Home/End, or Space. Selection loops.
Our implementation adds Previous/Pause/Next controls to the public reference presentation.
Hover, keyboard focus, and dragging pause autoplay. Hidden/offscreen views suspend autoplay too.
Reduced motion disables autoplay and animation but retains navigation.
Duplicate visual cards are hidden from screen readers. Empty arrays and single items are supported.
Failed images have a title/alt fallback.

Next.js App Router supports the included use client directive. For Pages Router, move the CSS import
to pages/_app.jsx.
