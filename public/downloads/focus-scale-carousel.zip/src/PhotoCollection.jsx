import FocusScaleCarousel from './components/FocusScaleCarousel';

const items = [
  { src: '/gallery/1.webp', title: 'Ferris Wheel', collection: 'Golden Hour',
    alt: 'Ferris wheel at golden hour' },
  { src: '/gallery/2.webp', title: 'Stingrays', collection: 'Shallows',
    alt: 'Stingrays gliding through clear water' },
  { src: '/gallery/3.webp', title: 'Forest Stream', collection: 'Old Growth',
    alt: 'A stream running through a mossy forest' },
  { src: '/gallery/4.webp', title: 'Kitesurfer', collection: 'Shallows' },
  { src: '/gallery/5.webp', title: 'Phone Booth', collection: 'Golden Hour' },
  { src: '/gallery/6.webp', title: 'Golden Hour', collection: 'Golden Hour' },
  { src: '/gallery/7.webp', title: 'The Cove', collection: 'Shallows' },
  { src: '/gallery/8.webp', title: 'Sunset Cliff', collection: 'Golden Hour' },
];

export default function PhotoCollection() {
  return (
    <FocusScaleCarousel
      items={items}
      cardWidth={320}
      cardHeight={430}
      gap={14}
      neighborScale={0.37}
      scaleDecay={0.78}
      sideCount={6}
      duration={850}
      autoPlay={4000}
      mobileScale={0.55}
      radius={2}
      showFrame={true}
    />
  );
}
