import FocusScaleCarousel from './components/FocusScaleCarousel';

export default function Lookbook() {
  return (
    <FocusScaleCarousel
      items={[
        { src: '/looks/one.webp', title: 'Tangerine Dream', collection: 'Studio Pop' },
        { src: '/looks/two.webp', title: 'Peach Hour', collection: 'Warm Room' },
        { src: '/looks/three.webp', title: 'Prism Gate', collection: 'After Dark' },
      ]}
      cardWidth={300}
      cardHeight={400}
      neighborScale={0.45}
      autoPlay={0}
      sideCount={3}
    />
  );
}
