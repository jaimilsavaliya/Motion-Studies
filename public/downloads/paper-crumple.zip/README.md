# Paper Crumple

An independently implemented React + Canvas 2D paper interaction. Hold an image to gather
it into a lit, seeded polygonal paper wad; drag while holding, then choose whether release
restores the page, leaves it crumpled, or keeps a faint network of creases. No 3D renderer,
physics engine, gesture package, copied reference source, demo image or remote API is in
this archive.

## Install

Copy `src/components/PaperCrumple.jsx` and `PaperCrumple.css` into a React 18+ app, then
use `src/FieldNote.jsx` or `src/CrumpledArchive.jsx` as a starting point. Pass an image
URL in `src`, useful alternative text, and leave enough parent height for the sheet to move.
The default scene is 360px tall; `style={{ height: ... }}` overrides `sceneHeight`.

The Canvas 2D API draws the supplied image. Use same-origin files or a remote image server
that sends CORS headers. If an image or canvas context is unavailable, the original image
remains as an ordinary fallback and `onError` receives the error.

## Props

- `src`: required image URL for the front of the sheet; PNG transparency is preserved.
- `alt`: `'Crumplable image'`; fallback description and accessible control name.
- `backSrc`: `''`; optional image for reverse-facing fold facets.
- `width` / `height`: `312` / `312`; unfolded pixels, each scaled down to leave a 24px
  stage inset and bounded 80–1600 / 80–1800.
- `sceneHeight`: `360`; stage height, bounded 180–1400. Inline style height wins.
- `imageFit`: `'contain'` (or `'cover'`); image fitting in the material texture.
- `releaseBehavior`: `'restore'` (or `'stay'`, `'creased'`).
- `crumpleAmount`: `0.85`, bounded 0–1; held compression.
- `crumpleDuration` / `releaseDuration`: `0.55` / `0.4` seconds, bounded 0–4. Zero is
  immediate.
- `foldCount`: `6`, bounded 3–16; seeded crease-guide count.
- `foldSharpness`: `0.6`, bounded 0–1; rounded-to-angular facet blend.
- `wrinkleDepth`: `0.65`, bounded 0–2; compression/facet relief.
- `creaseStrength`: `0.18`, bounded 0–1; residual lines when releaseBehavior is creased.
- `paperColor`: `'#f4f0e8'`; fallback/unprinted paper colour.
- `roughness` / `paperTexture`: `0.92` / `0.08`, each bounded 0–1; matte shadow and fine
  grain strength.
- `lightIntensity` / `lightAngle`: `1.8` / `-35`; fold facet lighting, bounded 0–4 and
  -180–180 degrees.
- `shadow`: true and `shadowOpacity`: `0.16`, bounded 0–1.
- `draggable`: true; direct manipulation while held.
- `dragRotation`: `10`, bounded 0–30 degrees; tilt during drag.
- `dragRadius`: `180`, bounded 0–600; maximum resting offset per axis.
- `returnToOrigin`: true; restore/creased modes return to center. Stay preserves offset.
- `rotation`: `0`, bounded -180–180 degrees; initial flat-page rotation.
- `seed`: `7`, bounded 0–9999; repeatable crease/facet/grain arrangement.
- `detail`: `64`, bounded 32–96; visual facet density.
- `disabled`: false; finishes interaction and prevents pointer/keyboard controls.
- `resetKey`: `0`; changing it immediately clears position, crumple and residual creases.
- `onStateChange`: lifecycle callback for holding, flat, crumpled, creased and releasing.
- `onError`: image/canvas error callback.
- `className`, `style`: optional root hooks.
- `ref`: optional `reset()` and `release()` helpers.

## Interaction, accessibility and performance

The visible sheet has a native button control. Pointer press begins the hold; pointer capture
keeps dragging reliable. Space or Enter holds, arrow keys move the sheet (Shift moves 24px),
and Escape resets it. Direct manipulation remains available under reduced motion, but
settling becomes immediate. All animation happens in one requestAnimationFrame loop and
stops at rest; observers, pointer capture and frames are cleared on unmount.

The component server-renders a labelled hold control and a normal image fallback without
accessing browser globals. Canvas visual output is hidden from assistive technology so the
image description is not duplicated.

Independent interpretation of the publicly observable interaction at
https://reactbits.dev/micro/paper-crumple. No React Bits source or demo media is
redistributed.
