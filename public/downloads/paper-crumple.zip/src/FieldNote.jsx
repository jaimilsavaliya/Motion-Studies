'use client';

import PaperCrumple from './components/PaperCrumple';

export default function FieldNote() {
  return (
    <PaperCrumple
      src="/images/field-note.webp"
      backSrc="/images/signal-grid.webp"
      alt="A handwritten note in ink"
      width={312}
      height={312}
      sceneHeight={360}
      releaseBehavior="restore"
      crumpleAmount={0.85}
      foldCount={6}
      draggable
    />
  );
}
