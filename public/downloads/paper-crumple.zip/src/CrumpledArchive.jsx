'use client';

import {useState} from 'react';
import PaperCrumple from './components/PaperCrumple';

export default function CrumpledArchive() {
  const [resetKey,setResetKey]=useState(0);
  return (
    <section>
      <PaperCrumple
        src="/images/archive-front.webp"
        backSrc="/images/archive-back.webp"
        alt="An archival map with a marked route"
        releaseBehavior="creased"
        creaseStrength={0.28}
        foldCount={9}
        wrinkleDepth={0.9}
        resetKey={resetKey}
      />
      <button onClick={() => setResetKey(value => value + 1)}>Flatten the note</button>
    </section>
  );
}
