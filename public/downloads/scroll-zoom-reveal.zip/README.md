# Scroll Zoom Reveal

An original React + CSS implementation of an inline-to-fullscreen scroll reveal.

## Installation

1. Copy src/components/ScrollZoomReveal.jsx and ScrollZoomReveal.css into your React project.
2. Add your own media to public/. The demo video is not included in this source archive.
3. Use src/Hero.jsx as a starting point. Media paths are examples; replace them with your assets.

Requires React 18 or newer and a build tool supporting CSS imports. No animation dependencies.

The component uses window scroll; avoid overflow: hidden or auto on ancestors.
The default scrollDistance=200 makes a section that is 300 viewport heights tall.

The component includes a use client directive for Next.js App Router.
For Next.js Pages Router, move the CSS import to pages/_app.jsx.

## Props

- leading: text before the media (default: Above)
- trailing: text after the media (default: the shoreline)
- radius: initial corner radius in pixels (default: 24)
- scrollDistance: positive scroll travel in viewport-height units (default: 200)
- onProgress: optional callback receiving a value from 0 to 1
- children: media element (required)

Reduced motion disables scroll interpolation but not the reveal itself.
For videos, provide a pause control and respect the user's autoplay preferences.

Original implementation by Motion studies. No proprietary Planes code is included.
