import ScrollZoomReveal from './components/ScrollZoomReveal';

export default function Hero() {
  return (
    <ScrollZoomReveal
      leading="Above"
      trailing="the shoreline"
      radius={24}
      scrollDistance={200}
    >
      <video
        src="/coast.mp4"
        poster="/coast-poster.jpg"
        autoPlay
        muted
        loop
        playsInline
      />
    </ScrollZoomReveal>
  );
}
