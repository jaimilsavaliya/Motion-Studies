import { useState } from 'react';
import GradientASCII from './components/GradientASCII';

export default function AsciiHero() {
  const [paused, setPaused] = useState(false);
  return <section style={{ position: 'relative', height: 620, overflow: 'hidden', background: '#101016', color: '#fff' }}>
    <GradientASCII
      colors={['#1e3fd8', '#f6f8ff', '#a5d8ff', '#38bdf8']}
      shape="horizon" characters=" =+xX0S8#@" cellSize={18}
      density={0.8} glyphOpacity={0.85} gradientOpacity={0.9}
      glow={0.2} depthOfField={0} flicker={0.2} softness={0.5}
      scale={1} flow={0.5} speed={1} grain={0.08} variation={0}
      mouseInteraction={true} scrambleRadius={0.1} clickEffect="wave"
      intro={true} lightMode={false} dpr={1.5} paused={paused}
      style={{ position: 'absolute', inset: 0 }}
    />
    <div style={{ position: 'relative', padding: 32, paddingTop: 400 }}>
      <h1>A little light. A lot of character.</h1>
      <button onClick={() => setPaused(value => !value)}>
        {paused ? 'Resume animation' : 'Pause animation'}
      </button>
    </div>
  </section>;
}
