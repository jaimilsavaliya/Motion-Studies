import GradientASCII from './components/GradientASCII';

export default function LightWash() {
  return <div style={{ height: 420, position: 'relative', background: '#f5f7fb', borderRadius: 20, overflow: 'hidden' }}>
    <GradientASCII shape="eclipse" lightMode intro={false}
      colors={['#48177b', '#9855e8', '#eabaff', '#fff0ff']}
      characters=" .:-=+*#%@" cellSize={16} density={0.6}
      gradientOpacity={0.35} glyphOpacity={0.9} glow={0.1}
      clickEffect="burst" mouseInteraction dpr={1.5} />
  </div>;
}
