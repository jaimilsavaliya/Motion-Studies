# Gradient ASCII

An independent React + WebGL implementation of an animated ASCII light field.
No third-party component source, fonts, images or rendering libraries are bundled.

## Install
Copy src/components/GradientASCII.jsx and GradientASCII.css into a React 18+ app.
Use AsciiHero.jsx or LightWash.jsx as a starting point. The component includes a
use client directive. In Next.js Pages Router, move the CSS import to _app.jsx.

Give the parent an explicit height. Use a relative parent and absolute component
for a background layer, with real HTML text and controls above it. The output is
transparent: choose a dark parent by default, or a pale one with lightMode.
The canvas is decorative/aria-hidden, not an accessible replacement for copy.

## Props (defaults)
colors: ['#1e3fd8','#f6f8ff','#a5d8ff','#38bdf8']; 2–8 valid CSS colors.
shape: 'horizon'; also 'pinch', 'rise', 'eclipse'.
characters: ' =+xX0S8#@'; ordered dim to bright, up to 128 Unicode code points.
  Empty string hides glyphs. A leading space supplies negative space.
cellSize: 18 CSS pixels; bounded 8–80, cell width = .62 * height.
density: .8, glyphOpacity: .85, gradientOpacity: .9; bounded 0–1.
  Zero density removes characters, zero gradient opacity leaves glyphs alone.
glow: .2 (0–1.5), depthOfField: 0 (0–1), flicker: .2 (0–1).
softness: .5 (0–1), scale: 1 (.4–2.5), flow: .5 (0–2).
speed: 1 (0–5); zero stops shape drift, not glyph flicker/interaction effects.
grain: .08 (0–.4), variation: 0 (-10000–10000).
mouseInteraction: true; pointer motion leaves a short-lived scramble trail.
scrambleRadius: .1 (.01–.5), relative to parent height.
clickEffect: 'wave'; 'burst' creates a local patch, 'none' disables clicks.
intro: true; source-led reveal and glyph decoding over 2.8 seconds.
lightMode: false; darker glyphs on a light parent. Does not change the page theme.
fontFamily: system monospace stack. Use an already-loaded font if desired.
dpr: current device ratio, capped at 2; optional cap .5–2.
paused: false; freezes all clocks and pointer effects. Initially paused shows
  a fully revealed field. Pausing during the reveal freezes its current state.
className/style: container presentation.

## Behavior and resilience
The renderer uses one draw call and a generated 512x384 glyph atlas. No remote
assets are requested. Render size is capped at eight million pixels and GPU limits.
Reduced motion skips the intro and renders a static field, without cursor effects.
Hidden tabs and offscreen backgrounds suspend frames and preserve animation time.
Observer/listener/RAF/GPU resources are cleaned up on unmount. Props update the
same renderer; loaded fonts refresh the atlas. A static blue gradient matching
the selected shape appears if WebGL is unavailable or its context is lost;
restoring the context initializes a new renderer. The fallback is not ASCII.

The canvas ignores pointer events and observes its parent without preventing
native actions. Links, buttons, form fields, contenteditable and data-ascii-ignore
regions are excluded from effects. Touch moves never create hover trails; taps
can trigger click effects, and vertical scrolling remains native. At most twelve
trail samples and four simultaneous clicks are retained.

Invalid numbers/colors/shapes are bounded or replaced with safe defaults. No
component-level theme toggle or library theme dependency is included.
