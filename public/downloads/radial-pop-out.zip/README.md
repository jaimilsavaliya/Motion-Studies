# Radial Pop-out

A React hero card with a spring-driven ring of related images.
Original implementation inspired by https://useplanes.com/components/radial-pop-out.
No proprietary Planes source is included.

## Installation

Copy src/components/RadialPopOut.jsx and RadialPopOut.css next to each other in your React 18+ project.
No motion library or utility CSS framework is required. The component uses the native Web Animations API.
Replace the sample image paths with your own assets. Reference images are not included in this archive.

The component reserves a square stage in normal flow and scales it down to available width.
At defaults its full-size stage is 820px, hero 280px, satellites 200px, and orbit radius 210px.

## Props

hero: { src, alt?, objectPosition? }
items: array of the same image shape, with optional rotation (-30 to 30 degrees). Default [].
heroSize: 280px; clamped 80–400.
cardSize: 200px; clamped 60–280.
orbitRadius: 210px; clamped 60–380.
stagger: 25ms; clamped 0–100.
tilt: 10 degrees; clamped 0–20.
magnetic: 0.36; clamped 0–0.5.
radius: 16px corner radius; clamped 0–48.
defaultOpen: false; read on mount only.
onOpenChange: optional callback receiving a boolean, not called on initial mount.
className: optional root CSS class.

Hover/focus the native button to expand; click/tap/Enter/Space toggles. Escape collapses.
Pointer exit closes a hover-only reveal. Toggled-open views also close on blur/outside pointer press.
Satellite images are visual previews, not links. Provide useful alt text.
Reduced-motion preference disables the animation, stagger, and hero tracking.
Missing or failed images have a named fallback. With no related images, the hero is static and disabled.

Next.js App Router can use the included use client component directly.
For Pages Router, move the CSS import to pages/_app.jsx.
