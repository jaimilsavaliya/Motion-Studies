import RadialPopOut from './components/RadialPopOut';

const hero = { src: '/radial-pop-out/japan.webp', alt: 'Japan' };
const items = [
  { src: '/radial-pop-out/fuji.webp', alt: 'Mount Fuji' },
  { src: '/radial-pop-out/hakone.webp', alt: 'Hakone at sunset' },
  { src: '/radial-pop-out/kyoto.webp', alt: 'Torii gates in Kyoto' },
  { src: '/radial-pop-out/osaka.webp', alt: 'An Osaka canal' },
  { src: '/radial-pop-out/ramen.webp', alt: 'A bowl of ramen' },
  { src: '/radial-pop-out/sakura.webp', alt: 'Cherry blossoms' },
  { src: '/radial-pop-out/shibuya.webp', alt: 'Shibuya at night' },
];

export default function Collection() {
  return (
    <RadialPopOut
      hero={hero}
      items={items}
      heroSize={280}
      cardSize={200}
      orbitRadius={210}
      stagger={25}
      tilt={10}
      magnetic={0.36}
      radius={16}
      defaultOpen={false}
    />
  );
}
