import RadialPopOut from './components/RadialPopOut';

export default function ProductCollection() {
  return (
    <RadialPopOut
      hero={{ src: '/products/featured.webp', alt: 'The new collection' }}
      items={[
        { src: '/products/one.webp', alt: 'Leather tote', rotation: -8 },
        { src: '/products/two.webp', alt: 'Canvas pouch', rotation: 6 },
        { src: '/products/three.webp', alt: 'Travel bag', rotation: -4 },
        { src: '/products/four.webp', alt: 'Wallet', rotation: 8 },
      ]}
      cardSize={140}
      heroSize={220}
      orbitRadius={170}
      tilt={0}
      magnetic={0}
    />
  );
}
