'use client';

import ScrollExpand from './components/ScrollExpand';

export default function MediaStage() {
  return (
    <section style={{height:'100vh'}}>
      <ScrollExpand
        src="/images/valley.webp"
        alt="A valley at sunrise"
        title="Built to scale"
        scrollHint="Scroll inside the frame"
      >
        <h2>Every pixel, everywhere</h2>
        <p>The frame opens up as you scroll and hands the whole stage to your media.</p>
      </ScrollExpand>
    </section>
  );
}
