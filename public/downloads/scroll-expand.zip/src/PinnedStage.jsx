'use client';

import ScrollExpand from './components/ScrollExpand';

export default function PinnedStage() {
  return (
    <section style={{background:'#100d16',color:'#fff'}}>
      <ScrollExpand
        useWindowScroll
        src="/images/city.webp"
        alt="A skyline at dusk"
        title="Hand it the screen"
        scrollHint="Keep scrolling"
        startWidth={50}
        startRadius={20}
        scrollDistance={0.9}
        holdDistance={0.35}
      >
        <h2>Pinned, then released</h2>
        <p>The page scroll drives the same expansion, then the section lets go.</p>
      </ScrollExpand>
      <div style={{minHeight:'60vh'}} />
    </section>
  );
}
