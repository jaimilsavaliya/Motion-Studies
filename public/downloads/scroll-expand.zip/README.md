# Scroll Expand

An independently implemented React component that expands a small media frame to full
bleed as the reader scrolls. No scroll library, animation package or copied reference
source is included, and the reusable core ships without any media assets.

## Install

Copy src/components/ScrollExpand.jsx and ScrollExpand.css into a React 18+ app, then use
src/MediaStage.jsx or src/PinnedStage.jsx as a starting point.

Give the component a definite height. In the default scroller mode it fills its parent
(height:100%), so wrap it in a section with an explicit height such as 520px or 100vh.
When the parent cannot define one, pass stageHeight. The component measures that height
and adds the expansion length and hold to build its own scroll track.

Set useWindowScroll to drive the same expansion from the page scroll instead. The section
is then content-sized: the sticky stage keeps the frame pinned while the track provides
the expansion distance, and the section releases once the hold ends.

## Props

- src: ''. Image or video URL. An empty source renders a labelled placeholder and skips
  the scroll listeners entirely.
- mediaType: 'image' | 'video', default 'image'. Video is muted, looping and inline, and
  pauses while reduced motion is set or the section is offscreen.
- poster: ''. Poster frame shown while a video loads.
- alt: ''. Alt text for the media and the accessible name of the region.
- title: ''. Headline held over the frame at rest; it lifts and fades as the frame opens.
- scrollHint: ''. Cue under the resting frame; fades out as soon as scrolling starts.
- startWidth / startHeight: 42 / 58. Resting frame size as a percentage of the stage,
  each bounded 10-100.
- startRadius / endRadius: 24 / 0. Corner radius in px at rest and at full bleed,
  bounded 0-48.
- mediaZoom: 1.35. Media scale at rest, bounded 1-2.5, easing back to 1 as the frame opens.
- scrollDistance: 1.2. Expansion length in multiples of the stage height, bounded 0.4-3.
- holdDistance: 0.35. Extra pinned scroll at full bleed, bounded 0-1.5 stage heights.
- smoothing: 0.1. Follow time in seconds, bounded 0-0.4. Zero locks the frame to the
  scrollbar; the frame always converges instead of drifting behind.
- overlayScrim: 0.45. Gradient scrim strength, bounded 0-1.
- useWindowScroll: false. Pin to the page scroll rather than the component scroller.
- enabled: true. When false the frame rests at its start size, listeners are removed and
  the track collapses.
- focusPoint: '50% 50%'. object-position used when the media is cropped.
- stageHeight: 0. Fixed stage height in px. Zero derives it from the parent height in
  scroller mode, or 64vh capped at 640px in page-scroll mode.
- onProgress: called with { progress, target, phase } when the smoothed value moves or
  the phase changes. Phases: rest, expanding, open, complete, static, placeholder.
- children: overlay content revealed at full bleed. Direct children receive heading and
  body styling; override it with your own classes.
- className, style: root class and inline styles, including inherited color.

## Accessibility and performance

Reduced motion removes smoothing and stops looping video while the scroll mapping stays
available. Offscreen sections and hidden tabs stop measuring and pause playback. The
scroller is focusable and labelled, the region is described by its scroll hint, and the
scrim is hidden from assistive technology. Every listener, observer, animation frame and
media handler is released on unmount, including StrictMode effect replay.

Preview-only controls (the progress readout and reset button in this site) are not part
of the component. The study's demo media is generated in-house and is intentionally not
included in this archive; add your own assets and descriptions.

Independent interpretation of the public visual reference at
https://reactbits.dev/animations/scroll-expand. No React Bits source is redistributed.
