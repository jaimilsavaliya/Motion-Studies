# Eclipse

An original procedural React + WebGL eclipse. No textures, Three.js, or animation packages.

## Install

Copy src/components/Eclipse.jsx and Eclipse.css next to each other in your React 18+ app.
The shader is embedded in Eclipse.jsx. Import the component using src/Hero.jsx as an example.

The parent needs position: relative and a non-zero height (e.g. 560px).
Eclipse fills the parent; put headings and controls after it. It is decorative and pointer-transparent.

## Props

- radius: 0.205. Fraction of the shorter container side, clamped 0.1–0.35.
- intensity: 1. Corona brightness, clamped 0–2; stars are independent.
- speed: 1. Time multiplier, clamped 0–3. Zero freezes drift, not pointer interaction.
- color: #eef0ff. Six-digit hex corona tint.
- interactive: true. Cursor-driven foreground disc, fixed corona, and opposite-edge exposure.
- paused: false. Pause animation; changed props may still draw one frame.
- pixelRatio: 1.5. Maximum render DPR, clamped 0.5–2, limited by device DPR.
- className: optional root CSS class.

## Accessibility and performance

Reduced-motion preference renders a still frame and disables pointer motion.
Use the pause-control example for long-running decorative animation.
The loop stops when offscreen or when the browser tab is hidden.
Use pixelRatio={1} to reduce GPU cost.
A simpler static CSS glow appears when WebGL is unavailable or its context is lost.
The CSS fallback uses modern container-query units and color-mix().

The use client directive supports Next.js App Router. For Pages Router, move the CSS import
from Eclipse.jsx into pages/_app.jsx.

Original implementation inspired by https://useplanes.com/components/eclipse.
No proprietary Planes source is included. The props above belong to this implementation.
