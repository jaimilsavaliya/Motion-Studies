'use client';

import { useState } from 'react';
import Eclipse from './components/Eclipse';

export default function EclipseHero() {
  const [paused, setPaused] = useState(false);

  return (
    <section style={{ position: 'relative', height: 560, background: '#000' }}>
      <Eclipse paused={paused} />
      <button
        type="button"
        onClick={() => setPaused(value => !value)}
        aria-pressed={paused}
        style={{
          position: 'absolute', bottom: 24, right: 24,
          color: '#fff', background: '#151515',
          border: '1px solid #555', padding: '8px 12px',
          borderRadius: 6, cursor: 'pointer',
        }}
      >
        {paused ? 'Play animation' : 'Pause animation'}
      </button>
    </section>
  );
}
