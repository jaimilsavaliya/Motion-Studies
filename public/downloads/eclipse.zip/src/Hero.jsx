import Eclipse from './components/Eclipse';

export default function Hero() {
  return (
    <section style={{ position: 'relative', height: 560, background: '#000' }}>
      <Eclipse
        radius={0.205}
        intensity={1}
        speed={1}
        color="#eef0ff"
        interactive
      />
      <h1 style={{
        position: 'absolute', inset: 0, display: 'grid',
        placeItems: 'center', color: '#fff', textAlign: 'center',
        margin: 0, fontSize: 'clamp(28px, 5vw, 56px)',
      }}>
        Your headline
      </h1>
    </section>
  );
}
