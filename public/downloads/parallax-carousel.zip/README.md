# Parallax Carousel

Independent React + CSS implementation inspired by https://useplanes.com/components/parallax-carousel.
No proprietary Planes source is included.

Copy ParallaxCarousel.jsx and ParallaxCarousel.css into the same folder in your React 18+ project.
No carousel, motion, or utility CSS package is required. Modern browsers need ResizeObserver,
IntersectionObserver, pointer capture, and CSS masks.
Replace sample image paths with your own appropriately licensed media. Demo images are not included.

## Props
images: array of { src, alt?, objectPosition? }; default [].
cardWidth: 320px; clamped 120–600.
cardHeight: 600px; clamped 160–800.
gap: 12px; clamped 0–48.
parallax: 60px max image shift; clamped 0–160.
speed: 34px/s; clamped -160–160. Positive moves left, negative moves right.
radius: 12px; clamped 0–48.
fade: 80px edge mask; clamped 0–160 and at most one third of container width.
mobileScale: .62; clamped .4–1, applied below 640px container width to sizes, gap, and parallax.
autoPlay: true.
pauseOnHover: true.
paused: false; external autoplay pause, manual movement remains enabled.
showControls: true; provide another pause control when false.
showDots: false; requires showControls.
onIndexChange: optional callback with nearest-center image index when it changes.
className: optional root class.

The strip is cardHeight + 24px tall. Leave about 50px below for the absolute-positioned controls.
Cards are free-dragging, not snapping. A drag release coasts briefly; hover smoothly pauses autoplay.
Mouse wheel and vertical touch scrolling are not intercepted.
Keyboard: focus the strip, use Left/Right, Home/End, or Space. Keyboard focus pauses autoplay.
Navigation controls and dots are additions to the public reference demo for accessibility.
Reduced motion removes autoplay, image drift, and inertia; manual button movements become instant.
Offscreen and hidden-tab loops stop. Extra image sets are aria-hidden. Empty and single-image arrays
are supported; failed images have an alt-text fallback.

Next.js App Router supports the included use client directive. With Pages Router, move the CSS import
to pages/_app.jsx.
