import ParallaxCarousel from './components/ParallaxCarousel';

export default function ProductGallery() {
  return (
    <ParallaxCarousel
      images={[
        { src: '/products/one.webp', alt: 'Ceramic vase, front view' },
        { src: '/products/two.webp', alt: 'Glaze detail', objectPosition: '60% center' },
        { src: '/products/three.webp', alt: 'The collection on a shelf' },
      ]}
      cardWidth={220}
      cardHeight={300}
      parallax={40}
      autoPlay={false}
      showDots
    />
  );
}
