import ParallaxCarousel from './components/ParallaxCarousel';

const images = [
  { src: '/gallery/1.webp', alt: 'Ferris wheel at golden hour' },
  { src: '/gallery/2.webp', alt: 'Stingrays in turquoise shallows' },
  { src: '/gallery/3.webp', alt: 'A stream through a mossy forest' },
  { src: '/gallery/4.webp', alt: 'Kitesurfer crossing the bay' },
  { src: '/gallery/5.webp', alt: 'A phone booth on a tropical beach' },
  { src: '/gallery/6.webp', alt: 'Evening light over the coast' },
  { src: '/gallery/7.webp', alt: 'A boat in a clear cove' },
];

export default function TravelGallery() {
  return (
    <ParallaxCarousel
      images={images}
      cardWidth={320}
      cardHeight={600}
      gap={12}
      parallax={60}
      speed={34}
      radius={12}
      fade={80}
      mobileScale={0.62}
      autoPlay={true}
      pauseOnHover={true}
      showDots={false}
    />
  );
}
