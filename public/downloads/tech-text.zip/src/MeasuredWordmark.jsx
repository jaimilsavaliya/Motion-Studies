'use client';

import {useState} from 'react';
import TechText, {techTextPresets} from './components/TechText';

export default function MeasuredWordmark() {
  const [paused,setPaused]=useState(false);
  return <section>
    <div style={{height:440,background:'#120f17',color:'#f4f1ea'}}>
      <TechText {...techTextPresets.serif} text="Studio"
        accentColor="#a8c4f5" fontSize={220} sweep={false}
        paused={paused}/>
    </div>
    <button onClick={()=>setPaused(value=>!value)}>
      {paused?'Resume entrance':'Pause entrance'}
    </button>
  </section>;
}
