'use client';

import {useState} from 'react';
import TechText from './components/TechText';

export default function Wordmark() {
  const [paused,setPaused]=useState(false);
  return <section>
    <div style={{height:480,background:'#120f17',color:'#fff',borderRadius:16,overflow:'hidden'}}>
      <TechText text="Tech Text" fontSize={150} fontWeight={600}
        reveal="letter" lineStyle="dashed" dashLength={4} dashGap={2}
        selection labels draggable clickKick sweep paused={paused}/>
    </div>
    <button onClick={()=>setPaused(value=>!value)}>
      {paused?'Resume motion':'Pause motion'}
    </button>
  </section>;
}
