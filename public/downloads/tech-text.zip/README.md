# Tech Text

An independently implemented React + Canvas 2D interactive wordmark. No renderer,
font-parser, animation package, remote API, image asset or copied reference source.

## Install

Copy src/components/TechText.jsx and TechText.css into a React 18+ app. Use Wordmark.jsx
or MeasuredWordmark.jsx as a starting point. Give the parent an explicit height, e.g.
480px, and choose its background/text color. The core is transparent and fills its parent.

Use any font already loaded in your app, or leave fontFamily empty to inherit. The demo
uses local OFL-licensed Geist/Geist Mono fonts; they are intentionally NOT included here.
The Mono preset falls back to the system monospace font when Geist Mono is unavailable.
No font or other media is fetched by the reusable component itself.

Next.js App Router supports the included use client directive. With Pages Router, move
the component CSS import into pages/_app.jsx. Browser work begins only after mount;
server rendering includes readable text until the canvas is ready.

## Props

- text: 'Tech Text'. Single-line text, limited to 96 graphemes. Line breaks become spaces.
- fontFamily: ''. Inherit the parent, or supply a loaded CSS font-family string.
- fontWeight: 600; bounded 100–900. Available weights depend on the loaded font.
- fontSize: 150; maximum CSS size, bounded 12–640. Shrinks to fit the width and at most
  48% of the stage height, leaving room for letter movement and labels.
- letterSpacing: -0.05; extra spacing in em, bounded -0.1–0.3. Kerning is included.
- align: center (default), left or right, within responsive stage gutters.
- color: currentColor. Fill, outline and original-position ghost color.
- accentColor: currentColor. Frames, handles, connector, labels, specks and guides.
- reveal: letter (default), area or off. Area blends fill into outline within a circular
  pointer lens; letter outlines one active glyph. Off leaves normal letters solid.
  Original-position ghost outlines during drag/kick are independent of this setting.
- reach: 200; area radius in CSS px, bounded 0–800. Letter mode ignores it.
- softness: 0.7; soft fraction of the area edge, bounded 0–1. Zero is a hard circle.
- dashLength / dashGap: 4 / 2 CSS px; bounded 0.5–32 / 0–24.
- lineStyle: dashed (default) or solid. Applies to cached glyph contours.
- strokeWidth: 1.5 CSS px; bounded 0.25–8.
- specks: 15; integer 0–64. Blinking squares around the active letter. Zero hides them.
  Assemble entrance particles are independent of this setting.
- selection: true. Gliding frame, corner handles and drag connector.
- labels: true. Letter/ink dimensions, or drag offsets with positive Y upward.
- draggable: true. Drag letters off the baseline, then spring back on release.
- bounce: 0.4; bounded 0–1. Zero gives a non-overshooting drag return.
- clickKick: true. Click or Enter kicks a letter and sends diminishing delayed impulses
  to up to six neighboring positions on each side. Dragging does not trigger a click kick.
- intro: none (default), type, assemble or metrics. Starts after font loading and visibility.
  Type reserves the final layout, outlining then filling letters in sequence. Assemble
  brings pixels into each glyph. Metrics draws font rules then fills horizontal zones.
  A pointer press or keyboard input skips an entrance. Changing text/intro restarts it.
- introDuration: 2 seconds; bounded 0.2–8. Hidden/offscreen/paused time is excluded.
- guides: false. Cap-height, x-height, baseline and descender rules when a letter is active.
  The Metrics entrance draws these rules temporarily even if guides is false.
- sweep: true. Autonomous reveal when pointer and keyboard input are away.
- speed: 1; idle sweep multiplier, bounded 0–5. Zero holds the sweep but does not stop specks.
- paused: false. Hold sweep, blinking and entrance progress. Manual input still works and
  user-initiated return springs may finish. Provide a pause control for decorative motion.
- pixelRatio: 1.5; capped to 0.5–2 and device DPR, three million pixels and a 4096px side.
- className: ''. Additional root class.
- style: optional root inline CSS.

Exported techTextPresets contains vector, lens, mono and serif configurations. Spread a
preset into the component; explicit following props override it. There is no preset prop.
Presets do not include text, color or a background, and do not load fonts.

## Interaction and accessibility

The wordmark is one named keyboard region, with stable text and a separate polite
announcement for keyboard selection. Canvas visuals are hidden from assistive technology.
Arrow keys select a letter; Home/End select the first/last non-space grapheme. Enter kicks.
Space picks up a letter; arrows move it by 8px, Shift+arrows by 24px, and Space/Enter releases.
Escape restores the baseline and suspends automatic sweeping until the next interaction
or sweep/pause setting change. A focus ring appears for keyboard use, never pointer dragging.

On touch, start a drag horizontally. Vertical swipes remain native page scrolling; pointer
cancellation returns the letter. Wheels and browser zoom are not intercepted. Pointer capture
is released on up/cancel/loss, setting changes, hiding, offscreen movement and unmount.

Reduced motion skips entrances, idle sweeps, blinking and click kicks. Direct inspection and
manual dragging remain available, with immediate return on release. No continuous animation
is scheduled for a quiet instance. Offscreen instances and hidden tabs suspend frames.

## Rendering and limits

The component rasterizes each distinct grapheme in the chosen font, follows directed pixel
boundary edges into closed contours, and simplifies the paths. Cached Path2D contours support
real dash/gap/stroke controls. Color changes do not need to retrace glyphs; font, text, size,
spacing and fit changes do. Font loading is observed, with a two-second fallback to an
available font, and late font loads rebuild measurements. Intro particles are capped to
roughly 2400 samples across the wordmark; glyph raster masks are capped at 750,000 pixels.

Best for short, single-line left-to-right Latin-like wordmarks. Grapheme segmentation keeps
combining characters/emoji together when Intl.Segmenter is available. Contextual joining,
ligatures and color glyph rendering can differ because each grapheme moves independently.
This is not a paragraph layout engine, editable text field or font-file exporter.

Canvas/Path2D unavailable: a readable responsive text fallback remains. The canvas background
is transparent; meaningful copy and headings should stay in normal HTML around the component.
Frames, font timers/callbacks, pointer capture, observers and event listeners are cleaned up on
unmount, including StrictMode effect replay. No remote resources are required by this source.

Independent interpretation of the public visual reference at
https://reactbits.dev/text-animations/tech-text. No React Bits source is redistributed.
