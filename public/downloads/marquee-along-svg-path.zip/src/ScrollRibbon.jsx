import { useRef } from 'react';
import MarqueeAlongSvgPath from './components/MarqueeAlongSvgPath';

export default function ScrollRibbon() {
  const scroller = useRef(null);
  return <section ref={scroller} style={{ height: 600, overflowY: 'auto' }}>
    <div style={{ height: 1000, paddingTop: 120 }}>
      <MarqueeAlongSvgPath path="M0 150 C250 0 750 300 1000 150"
        viewBox="0 0 1000 300" height={400} responsive repeat={4}
        useScrollVelocity scrollAwareDirection scrollContainer={scroller}
        slowdownOnHover slowDownFactor={0.2} draggable grabCursor
        cssVariableInterpolation={[{ property: 'opacity', from: 0.2, to: 1 }]}
        showControls>
        <div style={{ padding: 20, background: '#e896dc', color: '#1f464d' }}>Hello</div>
        <div style={{ padding: 20, background: '#1f464d', color: '#e896dc' }}>Again</div>
      </MarqueeAlongSvgPath>
    </div>
  </section>;
}
