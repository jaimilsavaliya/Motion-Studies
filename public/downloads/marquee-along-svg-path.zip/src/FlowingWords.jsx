import MarqueeAlongSvgPath from './components/MarqueeAlongSvgPath';

const path = 'M0 165 C166 -20 332 350 498 165 S830 -20 996 165';
const words = ['Make', 'something', 'move', 'with', 'feeling'];

export default function FlowingWords() {
  return <div style={{ overflow: 'hidden', background: '#fafafa', borderRadius: 16 }}>
    <MarqueeAlongSvgPath path={path} viewBox="0 0 996 330"
      height={530} responsive baseVelocity={8} direction="normal" repeat={2}
      draggable={true} grabCursor dragSensitivity={0.1}
      showPath={false} slowdownOnHover={false} slowDownFactor={0.3}
      enableRollingZIndex={true} showControls={true}>
      {words.map(word => <div key={word} style={{ padding: '14px 24px',
        borderRadius: 8, background: '#d8edbd', color: '#203019', fontSize: 24 }}>
        {word}
      </div>)}
    </MarqueeAlongSvgPath>
  </div>;
}
