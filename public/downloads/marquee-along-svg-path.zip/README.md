# Marquee Along SVG Path

Independent React + CSS implementation. React 18+, CSS motion paths, Pointer Events,
ResizeObserver and IntersectionObserver. No animation dependency or remote media.
Copy src/components/MarqueeAlongSvgPath.jsx and .css into your project.
FlowingWords.jsx and ScrollRibbon.jsx are asset-free examples. Demo artwork is excluded.

Required props: children and path (an SVG d string).
viewBox defaults to 0 0 100 100; set it to your path coordinate bounds.
width/height default to 100%; give the root or its parent a definite height.
responsive=false uses native coordinates. True scales the complete plane including
children, with preserveAspectRatio='xMidYMid meet'. Min/Mid/Max, slice and none work.
Nonzero viewBox origins are translated. Resize preserves animation progress.
showPath=false shows a dashed guide when true; pathId defaults to a generated ID.

baseVelocity=5 percentage points per second, bounded -100..100.
direction=normal (or reverse). repeat=3, bounded 1..20.
easing is an optional function mapping wrapped progress 0..1 to 0..1.
slowdownOnHover=false, slowDownFactor=0.3, bounded 0..1.
slowDownSpringConfig={damping:50,stiffness:400}; mass is also supported.
useScrollVelocity=false, scrollAwareDirection=false.
scrollContainer accepts an element or ref; a null ref falls back to window.
scrollSpringConfig has the same spring defaults. Speed gains 5x base speed per
1000px/s of smoothed absolute scroll velocity; direction can follow the scroll sign.
draggable=false, grabCursor=false. Horizontal drag moves the whole ribbon.
dragSensitivity=0.2 percentage points per viewport pixel, bounded 0..2.
dragVelocityDecay=0.96 (per 60Hz frame, converted to elapsed-time decay).
  Zero disables release coasting; values are bounded 0..0.999.
dragAwareDirection=false; true keeps the latest drag direction for base travel.
enableRollingZIndex=true, zIndexBase=1, zIndexRange=10.
cssVariableInterpolation=[]: objects {property,from,to} interpolate unitless numeric
  CSS properties or custom variables against eased progress. Use CSS calc() for lengths.
paused=false externally stops autoplay; showControls=false adds Pause/Resume and Reset.
className/style customize the root; aria-label names the region.

Use stable child keys and put size/style/transforms on the children, not .msp-item.
Images should set draggable={false}. Repeated content must avoid unique DOM IDs.
On open paths, elements wrap from the final point to the first; hide this with endpoints
outside an overflow:hidden stage. Closed paths can loop seamlessly. Increasing repeat
reduces spacing; it does not extend the path. Native offset-rotate follows its tangent.

Tab to the root pauses animation. Left/Right move 2%, Shift moves 10%, Home/Escape reset,
Space toggles pause; Tab leaves normally. Reduced motion stops autoplay/inertia but keeps
manual movement. First copies retain accessible children; duplicates are aria-hidden
and their interactive descendants have tabindex=-1. Input/media opt-outs can use
 data-drag-ignore. Native form controls do not initiate dragging. Actual drags suppress
accidental link navigation. Vertical touch scrolling is not blocked. Pointer cancellation
and capture outside the stage are supported. Animation stops offscreen, while hidden,
or when paused; all observers/listeners/frames are cleaned up on unmount.

The public showcase explicitly uses velocity=8, repeat=2, dragSensitivity=0.1 and
responsive=true. Its hover artwork enlargement is demo styling, not core behavior.
Next.js App Router is supported by use client. Pages Router should import CSS in _app.jsx.
