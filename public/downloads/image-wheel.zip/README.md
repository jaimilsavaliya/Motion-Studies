# Image Wheel

Independent React implementation inspired by the publicly rendered Image Wheel at
https://useplanes.com/components/image-wheel. No proprietary source is included.

Copy src/components/ImageWheel.jsx and ImageWheel.css together into a React 18+ app.
No animation library, WebGL, or carousel package is needed. Modern browsers require
ResizeObserver, IntersectionObserver, requestAnimationFrame, and pointer capture.

Supply images as { src, alt } objects, with descriptive alt text used for button labels.
Images are center-cropped into square rounded frames. Local and remote images work;
no WebGL CORS permissions are needed. Supply your own properly licensed assets.
Reference demo photographs are not included in this archive.

## Props
images=[]: collection of { src, alt }.
cardSize=190: unscaled square size, clamped 60–360px.
radius=420: horizontal arc radius, clamped 120–800px. Demo uses 430px.
height=520: unscaled stage height, clamped 200–800px.
angle=24: angular spacing, clamped 12–60 degrees.
blur=9: depth blur strength, clamped 0–18. Zero disables blur.
tilt=1: card rotation strength, clamped 0–2. Zero keeps cards upright.
initialIndex=0: clamped initial image, read on mount.
showControls=false: optional Previous/Next buttons and counter.
onIndexChange(index,image): called as the nearest centered image changes.
onSelect(index,image): called when an already-centered card is activated.
className: extra class for the full-width stage.

## Interaction
Drag horizontally to turn the wheel; release to snap to the nearest image.
Click a side card to center it. Clicking the centered card only calls onSelect.
No automatic playback, looping, wheel-scroll interception, or built-in lightbox.
The first and last images are navigation bounds.
Tab to the current image; Left/Right browse; Home/End jump to the endpoints.
Enter/Space activates a card. Vertical touch scrolling remains available.

The entire composition scales to its container, including stage height. Depth blur
is static: neighbouring images remain soft at rest while the front image is sharp.
Reduced motion skips the spring, retaining the depth styling. Rendering stops when
settled, offscreen, or in a hidden tab. Failed images display descriptive fallback text.

Next.js App Router supports the included use client directive. For Pages Router,
move the CSS import into pages/_app.jsx.
