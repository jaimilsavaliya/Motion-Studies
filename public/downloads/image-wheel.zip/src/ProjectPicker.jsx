import { useState } from 'react';
import ImageWheel from './components/ImageWheel';

const projects = [
  { src: '/covers/shore.webp', alt: 'Shore — an ocean study' },
  { src: '/covers/city.webp', alt: 'City — an urban journal' },
  { src: '/covers/forest.webp', alt: 'Forest — a field guide' },
];

export default function ProjectPicker() {
  const [selected, setSelected] = useState(1);
  return <>
    <ImageWheel images={projects} initialIndex={1}
      radius={320} cardSize={180} height={440}
      blur={5} tilt={0.5} showControls
      onIndexChange={setSelected} />
    <p>{projects[selected].alt}</p>
  </>;
}
