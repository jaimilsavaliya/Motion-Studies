import ImageWheel from './components/ImageWheel';

const images = [
  { src: '/images/coast.webp', alt: 'Golden light along the coast' },
  { src: '/images/forest.webp', alt: 'A stream through the forest' },
  { src: '/images/sea.webp', alt: 'A quiet turquoise bay' },
  { src: '/images/cliff.webp', alt: 'Sunset over the cliffs' },
];

export default function PhotoWheel() {
  return <ImageWheel
    images={images}
    cardSize={190}
    radius={430}
    height={520}
    angle={24}
    blur={9}
    tilt={1}
    initialIndex={0}
    showControls={false}
  />;
}
