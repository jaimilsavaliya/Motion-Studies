# Passage Gallery

An independently implemented React component that draws an endless corridor of photos on
a canvas 2D context and glides the camera through it. No 3D library, animation package,
shader or copied reference source is included, and the reusable core ships without any
image assets.

## Install

Copy src/components/PassageGallery.jsx and PassageGallery.css into a React 18+ app, then
use src/Hero.jsx or src/Archive.jsx as a starting point. The gallery fills its parent and
keeps a 420px minimum height, so give the parent a definite height, such as 100vh.

Photos are passed as items. Each entry takes a src, an alt and an optional title, which
is used by the caption. Remote images must allow cross-origin loading, because their
pixels are drawn into the canvas; add crossOrigin support or host them yourself.

## Props

- items: { src, alt, title? }[]. Photos placed across the four corridor faces. Without
  items, the gallery still renders its grid and any accent tiles.
- colors: ["#5227FF", "#FF9FFC"]. The two ends of the gradient used for accent tiles.
- backgroundColor: "#0a0a0a". Colour of the walls and of the distance the tunnel fades
  into. Grid lines adapt to its luminance, and "transparent" shows the page behind.
- lanes: 5. Horizontal tiles across the floor and ceiling, bounded 2-12. The wall-row
  count is stepped rather than equal to the horizontal count: 1-5 maps to 2 rows, 6-7
  to 3, 8-9 to 4, 10-11 to 5 and 12 to 6. Every tile remains square.
- gap: 0.1. Space between tiles as a fraction of a lane, bounded 0-0.4.
- radius: 0.06. Corner rounding as a fraction of the tile, bounded 0-1.
- photoFill: 0.3. Share of cells holding a photo, bounded 0-1.
- accentFill: 0.06. Share of cells holding a gradient accent, bounded 0-1.
- lineOpacity: 0.12. Opacity of the hairline grid, bounded 0-0.6. 0 removes it.
- fog: 1. How quickly the tunnel fades into the background with distance, bounded 0.2-3.
  Lower values keep colour deeper into the corridor.
- speed: 0.6. Cruising rate, bounded -2 to 4. It advances about 0.72 lanes per second
  for every unit; negative values travel backwards and 0 stays still.
- boost: 10. Speed multiplier while the pointer is held down, bounded 1-20.
- blur: 1. Strength of the motion smear at high speed, bounded 0-3.
- look: 1. How far the camera turns and shifts toward the pointer, bounded 0-3.
- fov: 72. Vertical field of view in degrees, bounded 40-100.
- hover: 1. Photo-only centre growth and brightening under the pointer, bounded 0-2.
- focusOnClick: true. Clicking a photo brings it out of the wall to full view; clicking
  again or pressing Escape puts it back.
- captions: true. Title and position of the opened photo, announced politely.
- wheel: true. Scroll to travel. Scrolling while a photo is open puts it back and moves
  on. Set false to leave page scrolling untouched.
- interactive: true. Pointer look, dragging, holding and clicking.
- seed: 0. Changes which cells hold photos and accents.
- paused: false. Stops cruising while dragging, holding and the keyboard keep working.
- dpr: 2. Maximum device pixel ratio for the backing store, bounded 0.5-3.
- ariaLabel: accessible description of the gallery and how to use it.
- onFocusChange: called with the opened item and its index, or null and -1.
- ref: imperative controls. close() puts an opened photo back, travel(cells) pushes the
  camera, and reset() returns to the entrance.
- children: centred over the tunnel and still interactive.
- className, style: root class and inline styles.

## How it works

Each frame the camera's travel position advances by the effective speed, the pointer adds
a smoothed yaw, pitch and lateral offset, and the tile ring in front of the camera is
projected with a plain perspective divide and painted back to front with distance fog.
Which cells hold photos, accents or nothing is a hash of the cell, face and seed, so a
corridor tile keeps its content as you pass it. The tile under the pointer is found by
projecting the visible tiles and testing the point against each quad, nearest first, so
there is no picking buffer. Photos on angled quads are drawn as a fan of triangles with
overlapping edges so the seams cannot show.

Motion blur at speed redraws the same frame at small depth offsets with reduced coverage
rather than running a post-processing pass.

## Accessibility and performance

The canvas is a focusable region described by ariaLabel, with a visually hidden list of
every photo. Arrow keys travel a cell, Page Up and Page Down jump a lane, Home returns to
the entrance, Enter opens the nearest photo and Escape puts it back. Reduced-motion users
never cruise, drag or smear, and offscreen instances and hidden tabs stop their animation
frame. Every listener, observer, frame and image handler is released on unmount, including
StrictMode effect replay. The backing store is capped by dpr and the current device ratio.

The demo scene collection in the study is generated in-house (
`scripts/passage-gallery-scenes.py`) and is intentionally not included in this
archive; add your own photos and descriptions.

Geometry notes measured against the reference: cells are one lane deep and tiles are
one-lane squares. The horizontal count is `lanes`; vertical wall rows follow the
stepped 1-5→2, 6-7→3, 8-9→4, 10-11→5, 12→6 mapping. The fills are weighted
(photoFill^0.62) and empty tiles stay black; hover grows a photo about its centre by
8% per unit and brightens it 29%; the visible depth is 27 / fog lanes.

Independent interpretation of the public visual reference at
https://pro.reactbits.dev/docs/components/passage-gallery. No React Bits source is
redistributed.
