'use client';

import { useRef } from 'react';
import PassageGallery from './components/PassageGallery';

const archive = [
  { src: '/images/one.webp', alt: 'Cover one', title: 'Cover one' },
  { src: '/images/two.webp', alt: 'Cover two', title: 'Cover two' },
  { src: '/images/three.webp', alt: 'Cover three', title: 'Cover three' },
];

export default function Archive() {
  const gallery = useRef(null);
  return (
    <section>
      <button type="button" onClick={() => gallery.current?.travel(6)}>Rush ahead</button>
      <button type="button" onClick={() => gallery.current?.close()}>Put the photo back</button>
      <div style={{ height: '100vh' }}>
        <PassageGallery
          ref={gallery}
          items={archive}
          colors={['#1d3cff', '#ff7a45']}
          backgroundColor="#0b0b12"
          lanes={4}
          photoFill={0.4}
          accentFill={0.1}
          speed={0.25}
          wheel={false}
          seed={12}
        />
      </div>
    </section>
  );
}
