'use client';

import PassageGallery from './components/PassageGallery';

const photos = [
  { src: '/images/ridge.webp', alt: 'A ridge at sunset', title: 'Ridge' },
  { src: '/images/tide.webp', alt: 'A ribbon of water', title: 'Tide' },
  { src: '/images/field.webp', alt: 'A field of colour', title: 'Field' },
];

export default function Hero() {
  return (
    <div style={{ height: '100vh' }}>
      <PassageGallery
        items={photos}
        speed={0.6}
        boost={10}
        fov={72}
        onFocusChange={(item, index) => console.log(item?.title ?? null, index)}
      >
        <h1>Walk the corridor</h1>
        <p>Hold to speed up. Click a photo to bring it forward.</p>
      </PassageGallery>
    </div>
  );
}
