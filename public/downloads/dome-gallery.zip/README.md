# Dome Gallery

An independently implemented React image gallery that arranges a compact set of images
across a dense, draggable hemisphere. It uses ordinary React, scoped CSS and native
Pointer Events — no 3D engine, gesture package or copied reference source. The archive
contains no demo photographs or remote assets.

## Install

Copy `src/components/DomeGallery.jsx` and `DomeGallery.css` into a React 18+ app, then
render it inside a parent with a definite height. `src/Hero.jsx` and
`src/ArchiveDome.jsx` are starting points. A 420px-or-taller parent gives the full dome
enough room, though the component also scales down for smaller embedded panels.

Pass image strings or objects with `src` and a useful `alt`. The supplied collection is
intentionally repeated over the surface, so a small, well-described image set produces
a full field. When no valid images are passed, the component uses self-contained abstract
fallback artwork rather than fetching a resource.

## Props

- `images`: `(string | { src: string, alt?: string })[]`, default built-in abstract
  studies. Source images repeated across the dome.
- `fit`: `0.5`, bounded `0.1–2`. Scales the radius derived from the chosen container
  dimension.
- `fitBasis`: `'auto' | 'min' | 'max' | 'width' | 'height'`, default `'auto'`. The
  dimension used by `fit`; auto and min select the smaller side.
- `minRadius`: `600`, bounded `80–4000`. Lower radius limit in pixels.
- `maxRadius`: `Infinity`. Optional upper radius limit; finite values are constrained
  between minRadius and 8000px.
- `padFactor`: `0.25`, bounded `0–0.48`. Padding allowance before the radius is fitted.
- `overlayBlurColor`: `'#120F17'`. Colour behind and around the soft edge veil.
- `maxVerticalRotationDeg`: `5`, bounded `0–30`. Vertical drag limit; zero creates a
  horizontal-only view.
- `dragSensitivity`: `20`, bounded `2–100`. Pixels per degree; a larger number feels
  slower.
- `enlargeTransitionMs`: `300`, bounded `0–1600`. Open/close transition duration.
- `segments`: `35`, bounded `12–64`. Horizontal density of the repeated field.
- `dragDampening`: `2`, bounded `0–5`. Inertia settling strength after release.
- `openedImageWidth`, `openedImageHeight`: `'400px'`. CSS size strings or numbers for
  the enlarged frame.
- `imageBorderRadius`, `openedImageBorderRadius`: `'30px'`. CSS radii for closed and
  enlarged images.
- `grayscale`: `true`. Set false to keep source image colours.
- `ariaLabel`: `'Dome image gallery'`. Accessible name for the interactive gallery.
- `className`, `style`: optional root styling hooks.
- `ref`: imperative `reset()`, `close()` and `rotate(x, y)` controls.

## Interaction, accessibility and performance

Drag the gallery or use Left/Right arrow keys to turn it. Click a visible image to bring
it forward; Escape or clicking the backdrop closes it. Each available tile is a native
button with an accessible label, while the stage is a labelled, focusable image-gallery
region. The selected image is a modal dialog with its own descriptive alt text.

The projection is recalculated from the stage size with ResizeObserver. Inertia uses one
requestAnimationFrame loop only while it has velocity, and is cancelled on reset or
unmount. The component preserves direct manipulation under reduced motion but removes
open/close animation timing. It server-renders the stage scaffold without accessing
browser globals.

Independent interpretation of the publicly observable interaction at
https://reactbits.dev/components/dome-gallery. No React Bits source or demo media is
redistributed.
