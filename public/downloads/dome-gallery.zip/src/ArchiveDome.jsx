'use client';

import DomeGallery from './components/DomeGallery';

const collection = [
  { src: '/images/one.webp', alt: 'A sunlit gallery wall' },
  { src: '/images/two.webp', alt: 'A pale sculptural study' },
  { src: '/images/three.webp', alt: 'A garden archive' },
  { src: '/images/four.webp', alt: 'A red window at dusk' },
];

export default function ArchiveDome() {
  return (
    <div style={{ height: 'min(72vw, 620px)' }}>
      <DomeGallery
        images={collection}
        fit={0.9}
        maxVerticalRotationDeg={6}
        dragDampening={2.6}
        openedImageWidth="440px"
        openedImageHeight="440px"
        grayscale={false}
      />
    </div>
  );
}
