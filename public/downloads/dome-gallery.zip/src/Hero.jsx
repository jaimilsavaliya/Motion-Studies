'use client';

import DomeGallery from './components/DomeGallery';

const images = [
  { src: '/images/portal.webp', alt: 'An amber portal in a red field' },
  { src: '/images/alcove.webp', alt: 'A blue geometric alcove' },
  { src: '/images/archive.webp', alt: 'A plum archival structure' },
];

export default function Gallery() {
  return (
    <section style={{ height: 520 }}>
      <DomeGallery
        images={images}
        fit={0.8}
        minRadius={600}
        segments={34}
        grayscale
      />
    </section>
  );
}
