import FlexCarousel from './components/FlexCarousel';

// Supply your own images. Demo photos are not included in the download.
const items = [
  { src: '/photos/sculpture.jpg', title: 'Iridescence', alt: 'An iridescent sculpture' },
  { src: '/photos/studio.jpg', title: 'White Room', alt: 'A portrait in a white studio' },
  { src: '/photos/chrome.jpg', title: 'Liquid Metal', alt: 'Reflective chrome surfaces' },
];

export default function FlexGallery() {
  return <div style={{ height: 540, overflow: 'hidden', borderRadius: 16 }}>
    <FlexCarousel items={items} preset="liquid" intro="rise" fit="natural"
      cardHeight={0.5} gap={12} radius={0} squeeze={0.2}
      focusOnClick={true} captions={true} captureWheel={true}
      autoplay={false} interval={4} showControls={true} pixelRatio={1.5}/>
  </div>;
}
