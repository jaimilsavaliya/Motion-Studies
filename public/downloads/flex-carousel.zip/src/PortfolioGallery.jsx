import { useState } from 'react';
import FlexCarousel from './components/FlexCarousel';

export default function PortfolioGallery({ projects }) {
  const [selected, setSelected] = useState('');
  return <section>
    <div style={{ height: 500, borderRadius: 20, overflow: 'hidden' }}>
      <FlexCarousel items={projects} preset="arch" intro="deal"
        fit="portrait" cardHeight={0.55} radius={12} gap={20}
        bend={0.25} dispersion={0.2} followCursor
        autoplay interval={5} showControls captureWheel={false}
        onChange={(index, item) => setSelected(item.title)} />
    </div>
    <p aria-live="polite">{selected}</p>
  </section>;
}
