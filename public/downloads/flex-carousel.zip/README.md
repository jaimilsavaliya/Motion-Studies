# Flex Carousel

An independent React + native WebGL infinite image gallery with a continuous
lens deformation, inertial navigation and inline click-to-focus. No third-party
component source or renderer package is bundled.

## Install
Copy src/components/FlexCarousel.jsx and FlexCarousel.css into a React 18+ project.
Supply your own image paths in FlexGallery.jsx, or pass projects to PortfolioGallery.
The showcase photographs are not included. No ogl, Three.js or motion package is needed.
Next.js App Router is supported with use client. For Pages Router, move the CSS
import to _app.jsx. Set an explicit parent height, e.g. 540px; the gallery fills it.

## Props
items=[]: up to 50 {src,alt?,title?,subtitle?,id?} objects. Use stable IDs and
  descriptive alt text. Natural fit uses loaded image dimensions. Empty arrays
  show a message, failed/CORS-blocked images show a named placeholder.
preset='liquid': liquid, ribbon, vortex, arch. Explicit lens props override it.
intro='rise': rise, bloom, spin, deal, none. An independent 1.5-second entrance
  after images settle; first input skips it. A new component mount replays it.
fit='natural': natural, portrait (3:4), square, landscape (4:3).
cardHeight=.5: fraction of stage height, .15–.85. gap=12, radius=0: 0–80px.
lensWidth/lensHeight: .2–1.6 and .2–2, relative to stage width; preset defaults.
tilt: -180–180 degrees. roundness: 0–1 (rounded rectangle to ellipse).
bend: 0–.9. reach: .05–.9. curl: twist, rise, fall. All default to preset values.
dispersion: 0–1.5, preset default. liquid: 0–1.5, default 0 in every preset.
followCursor=false: softly follow the pointer, returning on exit.
squeeze=.2: movement-dependent scale reduction, 0–.6.
focusOnClick=true: side-card clicks center first; selecting the centered image
  focuses it. Other images part/fade; bend relaxes and the image grows or fits
  within 86% of stage width. Click, drag, wheel, Escape or navigation closes it.
autoplay=false, interval=4: advance one image every 1–30 seconds.
  Pauses on hover, focus, interaction, inline focus, hidden/offscreen and reduced motion.
captions=true: title, subtitle and rolling counter below the row.
captureWheel=true: vertical wheel navigation. Horizontal/Shift-wheel always works.
onChange(index,item): emitted on a different centered item; not on initial load.
onSelect(index,item): selecting the centered item, even with focusOnClick=false.
initialIndex=0: initial item, clamped, read on first load.
showControls=false: Previous/Next, a Close button in focus, and Pause/Play if autoplay.
paused=false: pause autoplay externally; manual input still works.
pixelRatio=1.5: cap .5–2, additionally bounded by GPU limits and 8M render pixels.
className/style/aria-label: root styling and accessible carousel name.

Preset lens values:
liquid: width .74, height 1.18, tilt 62, roundness 1, bend .34, reach .38,
  curl twist, dispersion .45.
ribbon: width .8, height .8, tilt 0, roundness 1, bend .34, reach .34,
  curl twist, dispersion .4.
vortex: width .7, height .95, tilt 30, roundness 1, bend .46, reach .3,
  curl twist, dispersion .5.
arch: width .8, height .8, tilt 0, roundness 1, bend .3, reach .36,
  curl rise, dispersion .4.

## Input and accessibility
Focus the region, then use Left/Right, Home/End, Enter/Space and Escape. Cards
also have named native buttons for assistive navigation. The canvas is decorative;
titles/counters are hidden from assistive technology and a polite live region
announces the centered image. Inline focus does not lock the page or trap focus.
Horizontal touch drags use capture only after intent is clear. Vertical touch
scrolling and Ctrl/Meta wheel zoom remain native. Add data-flex-ignore to custom
controls. Turn captureWheel off if vertical scrolling should stay with the page.

Reduced motion skips intro, inertia, cursor following and autoplay; manual
navigation and inline focus settle immediately. Idle/offscreen/hidden galleries
stop rendering. Resize keeps the current item and its relative scroll position.
Without WebGL, or while a context is lost, a straight DOM gallery retains the
navigation/focus controls. Restoration rebuilds the WebGL textures and mesh.

The original mesh uses 40x12 subdivisions per visible image, with shared stage
coordinates for the lens. Only nearby repeated images are drawn. Textures are
bounded to 1100px on their longest edge. Use compressed images on a host allowing
cross-origin texture access. Image loads time out to a placeholder after 12 seconds.
Listeners, observers, pending image handlers, GPU resources, animation frames and
autoplay timers are released on unmount. The renderer is an independent visual
approximation, not a redistribution of the reference implementation.
