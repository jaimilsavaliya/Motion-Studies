import HoverReveal from './components/HoverReveal';

const team = [
  {
    name: 'Alex Morgan',
    src: '/team/alex.webp',
    alt: 'Alex Morgan, creative director',
    objectPosition: '50% 30%',
  },
  {
    name: 'Sam Rivera',
    src: '/team/sam.webp',
    alt: 'Sam Rivera, lead designer',
  },
];

export default function Team() {
  return (
    <HoverReveal
      label="Our people"
      items={team}
      theme="light"
      initialIndex={0}
      drift={false}
      parallax={0}
    />
  );
}
