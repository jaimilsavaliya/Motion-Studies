import HoverReveal from './components/HoverReveal';

const items = [
  { name: 'Blackframe', src: '/hover-reveal/blackframe.webp' },
  { name: 'Novagrid', src: '/hover-reveal/novagrid.webp' },
  { name: 'Ather', src: '/hover-reveal/ather.webp' },
  { name: 'Phantom', src: '/hover-reveal/phantom.webp' },
  { name: 'Obsedian', src: '/hover-reveal/obsedian.webp' },


];

export default function ProjectIndex() {
  return (
    <HoverReveal
      label="Protocols"
      items={items}
      duration={770}
      zoom={1.4}
      parallax={9}
      drift
      radius={18}
      theme="dark"
    />
  );
}
