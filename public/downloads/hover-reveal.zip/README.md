# Hover Reveal

An original React image index inspired by the public visual reference.

## Installation

1. Copy src/components/HoverReveal.jsx and HoverReveal.css into your React 18+ project.
2. Add your own images and update the src fields in the example. No reference images are included.
3. Import and render the component. It needs no positioned parent or fixed height.

Uses React, CSS container queries, and the native Web Animations API. No extra animation packages.

## Props

- items: array of { name, src, alt?, objectPosition? }. Default: [].
- label: header above the index. Default: Protocols. Empty string hides it.
- initialIndex: initially selected index. Default: 0; read only on mount, clamped to array bounds.
- duration: crossfade duration in ms. Default: 770; clamped to 0–2500. Zoom settles over about 1.82x this duration.
- zoom: entry scale. Default: 1.4; clamped to 1–1.8.
- parallax: maximum pointer displacement per axis in px. Default: 9; clamped to 0–20.
- drift: enable slow 8px vertical float. Default: true.
- radius: outer corner radius in px. Default: 18; clamped to 0–40.
- theme: dark or light. Default: dark.
- onActiveChange: optional callback (index, item), fired on a selection change, not initial mount.
- className: optional root CSS class.

## Interaction and accessibility

Hover, focus, or tap a native button to select an image. The last selection persists on pointer exit.
Arrow keys move through the list; Home and End jump to its ends.
A polite live region announces the selected name. Supply descriptive alt text.
Reduced-motion preference removes all image motion, fades, and text skew.
Set drift={false} and parallax={0} to remove continuous image movement for everyone.

Images load up front; use a small curated list and compressed assets. Failed images have a named fallback.
CSS container queries stack the layout below roughly 768px.

Next.js App Router: use the component as-is; it includes use client.
Next.js Pages Router: move the CSS import to pages/_app.jsx.

Visual reference: https://useplanes.com/components/hover-reveal
No proprietary Planes source is included. Demo image paths are examples; supply your own media.
