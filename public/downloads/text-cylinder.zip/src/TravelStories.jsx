import TextCylinder from './components/TextCylinder';

const slides = [
  {
    src: '/images/fuji.webp',
    alt: 'Mount Fuji behind a local train',
    lines: ["Mount Fuji", "Above the clouds"],
    color: '#2f5fb3',
    label: 'Yamanashi',
  },
  {
    src: '/images/kyoto.webp',
    alt: 'Rows of orange torii gates in Kyoto',
    lines: ['Kyoto', 'A thousand gates'],
    color: '#e0521b',
    label: 'Fushimi',
  },
  {
    src: '/images/shibuya.webp',
    alt: 'Neon signs on a Shibuya street at night',
    lines: ['Shibuya', 'After midnight'],
    color: '#d6266b',
    label: 'Tokyo',
  },
  {
    src: '/images/sakura.webp',
    alt: 'Cherry blossoms around a street lamp',
    lines: ['Sakura', 'First bloom'],
    color: '#c2185b',
    label: 'Spring',
  },
];

export default function TravelStories() {
  return (
    <TextCylinder
      slides={slides}
      speed={18}
      fontScale={0.24}
      imageWidth={22}
      mobileImageWidth={46}
      duration={700}
      initialIndex={0}
      paused={false}
      theme="dark"
    />
  );
}
