import { useState } from 'react';
import TextCylinder from './components/TextCylinder';

const projects = [
  { src: '/work/studio.webp', lines: ['Studio North', 'Independent ideas'],
    color: '#2444b8', label: 'Identity', alt: 'Studio North brand identity' },
  { src: '/work/objects.webp', lines: ['Everyday objects', 'A fresh perspective'],
    color: '#ae3a16', label: 'Product', alt: 'A collection of ceramic objects' },
];

export default function SelectedWork() {
  const [paused, setPaused] = useState(false);
  return (
    <>
      <button onClick={() => setPaused(value => !value)}>
        {paused ? 'Resume rotation' : 'Pause rotation'}
      </button>
      <TextCylinder
        slides={projects}
        speed={12}
        paused={paused}
        showControls={false}
        theme="light"
      />
    </>
  );
}
