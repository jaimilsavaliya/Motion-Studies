# Text Cylinder

An independent React + CSS implementation inspired by https://useplanes.com/components/text-cylinder.
No proprietary Planes source is included.

## Install

Copy TextCylinder.jsx and TextCylinder.css from src/components/ into the same folder in your React 18+ project.
No motion library, Tailwind, or WebGL renderer is required. A small canvas is used only to measure glyphs.
The visible typography is regular DOM text using CSS 3D transforms.

Replace sample image paths with your own appropriately licensed images. Demo media is not included.
The default stage is 16:10, or 4:5 on small viewports. For a full-height hero, pass a className with
height: 100svh; aspect-ratio: auto. Keep the bundled system font so glyph measurements remain accurate.

## Props

slides: array of { src, lines: [title, subtitle?], color?, label?, alt?, objectPosition? }; default [].
speed: 18 degrees/second; -60 to 60. Negative reverses direction. Zero freezes rotation.
fontScale: .24 of component height; .12 to .4, minimum 24px type.
imageWidth: 22%; 12 to 45.
mobileImageWidth: 46%; 30 to 75, used below 640px container width.
duration: 700ms image reveal; 200 to 1500. Text crossfade lasts up to 450ms.
initialIndex: 0; read on mount, wrapped to slide count.
paused: false; externally freezes rotation but not slide navigation.
showControls: true; supply your own pause control if false.
theme: dark or light; default dark.
onSlideChange: optional (index, slide) callback, not called on mount.
className: optional CSS class.

Click/tap/Enter/Space advances. Arrow keys browse while the photo button is focused.
Repeated decorative text is aria-hidden; a live region announces the selected slide.
Reduced motion freezes rotation and disables wipes/crossfades. Offscreen rotation is suspended.
Slides do not advance automatically. Rapid clicks keep at most two photo/text layers.
Empty slides show a placeholder; failed images show a named fallback.

Title rendering uses at most two lines, 100 characters per line, and eight phrase repetitions.
Modern browsers need ResizeObserver, IntersectionObserver, CSS 3D transforms, and container queries.
Next.js App Router supports the included use client directive. For Pages Router, move the CSS import
to pages/_app.jsx.
