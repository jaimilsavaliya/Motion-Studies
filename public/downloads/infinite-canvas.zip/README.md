# Infinite Canvas

Independent React + CSS implementation. React 18+, CSS imports, ResizeObserver,
Pointer Events and CSS container query units are required. No motion package or paid registry.
Copy src/components/InfiniteCanvas.jsx and InfiniteCanvas.css into your project.
Demo images are excluded. Supply your own appropriately licensed media.

## API
images: optional array of URLs or {src, alt, id?, objectPosition?}. Overrides path generation.
imageRootPath: empty by default; otherwise generates sequential img1.png, img2.png, etc.
numberOfImages: 15, bounded 0–200, used only with imageRootPath.
imageSize: auto; 15% of component width at >=1024px, 45% below.
  Numbers mean pixels; CSS lengths are supported. vw units resolve against component width.
gap: 5vw, also used as tile padding; adjoining tiles therefore have a double-width gap.
columns: 5, bounded 1–12 and the number of images. Incomplete final rows repeat as-is.
height: 720; numbers clamp 240–1200px, or use a definite CSS height such as 100svh.
backgroundColor: #f5f4f3. borderRadius: 24, clamped 0–64px.
showControls: false; enable to show an interaction hint and Reset view button.
aria-label: Infinite image canvas. className: additional root class.

Images use object-fit:contain, preserving the full picture in each square cell.
The default showcase uses 15 images and five columns. Sizing is container-relative.
Image size is bounded below by max(24px, stage width/40, stage height/40), above by 2400px.
Gaps are bounded to 0–1200px. These limits keep tiny configurations from exploding the DOM.
Empty collections show an empty state; failed images have a fallback.

Wheel input moves one-for-one; mouse/touch dragging has a 2x gain. Input updates an
accumulated target with a 1500ms quintic ease-out. Release adds no extra velocity.
Pointer hover alone does nothing. The animation loop stops once settled and coordinates
are periodically rebased. A bounded bank of tiles covers both axes at every phase,
including tall mobile viewports. Resize preserves the current tile phase.

Input is captured only inside the stage. Shift-wheel pans horizontally; Ctrl/Command-wheel
and pinch zoom remain available to the browser. Pointer capture handles drags leaving the
stage and cancellation. Arrow keys move by one cell/gap; Page Up/Down pan 85% of stage
height. Home or Escape resets the origin. Tab leaves the canvas normally.
Reduced motion snaps to the target without easing. Only one copy of each image is exposed
to assistive technology; repeated tiles are aria-hidden. Supply descriptive alt text.

The use client directive supports Next.js App Router. With Pages Router move the CSS import
into pages/_app.jsx. No remote runtime asset or external service is built into the component.
