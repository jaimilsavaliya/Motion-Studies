import InfiniteCanvas from './components/InfiniteCanvas';

const images = [
  { src: '/images/portrait.webp', alt: 'Portrait in warm afternoon light' },
  { src: '/images/landscape.webp', alt: 'A quiet desert landscape' },
  { src: '/images/sculpture.webp', alt: 'Reflective silver sculpture' },
  // Add the rest of your collection here.
];

export default function Collection() {
  return <InfiniteCanvas images={images} height={720}
    imageSize="auto" gap="5vw" columns={5}
    backgroundColor="#f5f4f3" borderRadius={24}
    showControls={false} />;
}
