import InfiniteCanvas from './components/InfiniteCanvas';

export default function ImageArchive() {
  return <InfiniteCanvas imageRootPath="/images/archive"
    numberOfImages={20} imageSize="20vw" gap="8vw"
    height="100svh" showControls={true} />;
}

// Place img1.png through img20.png in public/images/archive/.
// Pass an images array instead when you need custom paths or descriptive alt text.
