import BentoGrid from './components/BentoGrid';

const items = [
  { id: 'neon', src: '/photos/neon.webp', title: 'Neon run',
    eyebrow: 'Night', alt: 'A silver car under neon lights',
    description: 'Colour and reflections on a late-night drive.',
    colSpan: 2, rowSpan: 2 },
  { id: 'wheel', src: '/photos/wheel.webp', title: 'Low and wide',
    eyebrow: 'Detail', description: 'A closer look at the details.' },
  { id: 'tail', src: '/photos/tail.webp', title: 'Tail light',
    eyebrow: 'Detail', description: 'A flash of red in the dark.', rowSpan: 2 },
  { id: 'interior', src: '/photos/interior.webp', title: 'After hours',
    eyebrow: 'Interior', description: 'The view from the driving seat.' },
  { id: 'trails', src: '/photos/trails.webp', title: 'Light trails',
    eyebrow: 'Motion', description: 'The city, drawn in light.', colSpan: 2 },
  { id: 'station', src: '/photos/station.webp', title: 'Last stop',
    eyebrow: 'Night', description: 'One more stop before heading home.', colSpan: 2 },
];

export default function PhotoStories() {
  return (
    <BentoGrid
      items={items}
      columns={4}
      gap={12}
      rowHeight={220}
      mobileRowHeight={150}
      radius={12}
      sidebarWidth={400}
      duration={700}
      theme="dark"
    />
  );
}
