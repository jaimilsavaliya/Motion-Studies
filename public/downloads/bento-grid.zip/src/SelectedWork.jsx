import BentoGrid from './components/BentoGrid';

export default function SelectedWork() {
  return (
    <BentoGrid
      columns={3}
      rowHeight={240}
      theme="light"
      items={[
        {
          id: 'identity', src: '/work/identity.webp',
          title: 'Studio identity', eyebrow: 'Brand design',
          alt: 'A collection of printed brand materials',
          colSpan: 2, rowSpan: 2,
          description: <><p>A new identity for an independent studio.</p>
            <p>Strategy, typography, and a complete visual system.</p></>,
          credit: 'Your studio', creditHref: 'https://example.com',
        },
        { id: 'objects', src: '/work/objects.webp', title: 'Everyday objects',
          description: 'Thoughtfully designed objects for daily life.' },
        { id: 'space', src: '/work/space.webp', title: 'A place to create',
          description: 'A workspace built for collaboration.' },
      ]}
    />
  );
}
