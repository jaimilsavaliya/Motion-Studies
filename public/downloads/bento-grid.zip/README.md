# Bento Grid

An independent React implementation inspired by https://useplanes.com/components/bento-grid.
No proprietary Planes source is included.

## Install
Copy BentoGrid.jsx and BentoGrid.css from src/components into the same directory in your React 18+ project.
Requires react and react-dom, CSS Grid, ResizeObserver, native dialog, and the Web Animations API.
No animation package or utility CSS framework is required.

Supply your own appropriately licensed images. Demo photos are not in this archive.
Use the PhotoStories and SelectedWork examples as starting points.

## Props
items: array of { id, src, title, alt?, eyebrow?, description?, colSpan?, rowSpan?, objectPosition?, credit?, creditHref? }.
description accepts text or React content. IDs should be unique.
Column spans are limited to the available columns; row spans are clamped to 1–3. Both default to 1.
Credit URLs support http(s), root-relative paths, or hash links.
columns: 4; clamped 1–6, at most 2 below 640px container width.
gap: 12px; clamped 0–32.
rowHeight: 220px; clamped 100–400.
mobileRowHeight: 150px; clamped 80–300.
radius: 12px; clamped 0–40. Expanded photo corners are 16px.
sidebarWidth: 400px; clamped 280–520 and capped at 48% of viewport width.
duration: 700ms expansion/return; clamped 250–1200.
theme: dark (default) or light.
onActiveChange: optional (index, item) callback, receiving null, null when closed.
className: optional root class; use for your max-width.

Below a 768px viewport the details stack beneath the image. The description panel scrolls independently.
The modal is portalled to document.body. Native dialog keeps the background inert; body scrolling is locked.
An iframe preview confines its modal to that iframe.

Tiles support Enter/Space. Arrow keys browse without wrapping; Previous/Next disable at the ends.
Escape, Close, or clicking the backdrop dismisses. Focus returns to the selected tile.
Reduced motion disables hover zoom, expansion, and fades. Missing images show a named fallback.
Empty arrays display a placeholder. Resizing an open dialog settles its layout immediately.

Next.js App Router supports the included use client directive. With Pages Router, move the CSS import
to pages/_app.jsx.
