# Dither Veil

An independently written React image reveal using Canvas 2D and native WebGL.
No renderer package, copied reference code, remote font or bundled image is required.

## Install

Copy DitherVeil.jsx and DitherVeil.css from src/components/ into a React 18+ project.
Use VeiledImage.jsx or ReverseVeil.jsx as a starting point. Give the parent an explicit
height (e.g. 600px). The component fills the parent; add rounding and overflow:hidden there.
Supply your own appropriately licensed image. Demo media is not included in this archive.

Same-origin images and image data URLs work without extra server setup. Remote image hosts
must allow anonymous CORS requests so the image can be processed and uploaded to WebGL.
Use compressed raster images; use a still frame for animated media.

Next.js App Router supports the included use client directive. For Pages Router, move the
CSS import into pages/_app.jsx. All browser work is deferred until mount; the component is
safe to render on the server with a loading placeholder.

## Props

- src: image source, default ''. Empty sources display a placeholder.
- alt: accessible image description, default 'Interactive dithered image'.
- fit: contain (default) or cover. Contain adds ink-colored space; cover center-crops.
- pattern: floyd (default), bayer, noise, atkinson or lines.
- palette: duotone (default) or rgb. Duotone uses a print-like 1.5-power luminance curve
  before contrast/brightness and maps the result between ink and paper. RGB quantizes
  each original channel independently. Revealed original colors are never adjusted.
- pixelSize: 2. Target CSS cell size, bounded 1–20. Budget limits may increase it.
- levels: 2. Tones per channel, rounded and bounded 2–8.
- inkColor: '#120f17'. Dark duotone and contain background color.
- paperColor: '#f4f1ea'. Light duotone color. RGB mode does not use the duotone ramp.
- contrast: 1.15. Pre-dither contrast, bounded 0–3.
- brightness: 0. Pre-dither tone/channel offset, bounded -1–1.
- revealRadius: 200. Manual/wandering radius in CSS px, bounded 0–1000.
  Zero hides these windows; click ripples are independent.
- softness: 0.6. Dissolving fraction of the radius, bounded 0–1. Zero gives a hard edge.
- linger: 1. Trail lifetime in seconds, bounded 0–5. Zero disables the trail.
- rimColor: '#a78bfa'. Color of cells along the transition edge.
- rim: 0. Colored-cell band thickness, bounded 0–1. Zero hides it.
- reverse: false. Start with the original and reveal dither instead.
- wander: false. Drift a reveal window while there is no manual pointer/keyboard window.
- clickBurst: true. Click, tap, Enter or Space sends an expanding reveal ring.
- paused: false. Hold the last autonomous wandering position. Manual reveals, lingering
  trails and short click ripples still work. Provide a pause control when enabling wander.
- pixelRatio: 1.5. Maximum rendering DPR, bounded 0.5–2 and the device's DPR.
- className: ''. Additional root class.
- style: optional root inline styles.

Colors accept canvas-compatible CSS colors and render as opaque RGB.
Invalid numeric values and unknown enum values fall back to documented defaults.

## Dithering and rendering

Floyd–Steinberg and Atkinson are genuine serpentine error-diffusion passes, performed only
when image, dimensions, pixel size, palette or tonal settings change. Bayer is a conventional
8x8 ordered threshold matrix. Noise uses a deterministic progressive farthest-point tile
on a periodic 32x32 domain; lines use diagonal engraving bands. The reveal edge uses an
ordered cell threshold, not a blur applied to the original image.

A small Canvas field holds the union of radial windows. One WebGL draw composites the
original, cached dither and this field. Trails retain at most 32 sampled positions, and
at most four overlapping click rings are retained. Dither processing is bounded to roughly
600,000 cells and rendering to four million pixels and a maximum 4096px/GPU texture side.
For exceptionally large frames the effective CSS cell size increases to stay within budget.
An active reveal stays sharp at the configured render DPR, not at the dither resolution.

## Input and accessibility

Move the pointer or touch the image to reveal. The region is named by alt and has concise
screen-reader instructions. Tab to the image, then use arrows (24px) or Shift+arrows (64px).
Home recenters. Enter/Space ripples if enabled. Escape clears all windows and suspends
wandering until another interaction or wandering/pause setting change. Focus is never trapped.
Vertical touch scrolling, mouse wheels and browser zoom remain native.

Reduced-motion preference preserves immediate direct reveals but removes trails, click
ripples and wandering. Idle frames stop; hidden tabs and offscreen instances suspend rendering
and clear manual interactions. Pause wandering freezes its last position rather than blanking it.

No WebGL, a shader failure or a lost context switches to an interactive Canvas 2D renderer
with the same patterns and reveal behavior. Restoring the context rebuilds GPU resources.
If image processing cannot access pixels, an ordinary image is shown when it can load, with
an explanatory note. Broken sources show a named placeholder; image requests have a 12s timeout.
Frames, observers, event listeners, in-flight image handlers, timers and GPU resources are
cleaned up on unmount. Dynamic source changes invalidate stale load callbacks.

Independent implementation of the public visual interaction at
https://reactbits.dev/animations/dither-veil. No React Bits source is redistributed.
