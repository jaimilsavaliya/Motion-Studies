'use client';

import {useState} from 'react';
import DitherVeil from './components/DitherVeil';

export default function ReverseVeil() {
  const [paused,setPaused]=useState(false);
  return <section>
    <div style={{height:540,borderRadius:20,overflow:'hidden'}}>
      <DitherVeil src="/photos/sculpture.jpg"
        alt="A reflective sculpture with colorful highlights"
        pattern="bayer" palette="rgb" pixelSize={3}
        levels={3} reverse wander paused={paused}
        rim={0.2} rimColor="#a78bfa" linger={1.4}/>
    </div>
    <button onClick={()=>setPaused(value=>!value)}>
      {paused?'Resume wandering':'Pause wandering'}
    </button>
  </section>;
}
