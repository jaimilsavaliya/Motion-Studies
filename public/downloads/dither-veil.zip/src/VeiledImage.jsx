import DitherVeil from './components/DitherVeil';

export default function VeiledImage() {
  return <div style={{height:600,overflow:'hidden',borderRadius:16}}>
    <DitherVeil src="/photos/sculpture.jpg"
      alt="An iridescent sculptural head, looking upward"
      fit="contain" pattern="floyd" palette="duotone"
      pixelSize={2} levels={2} contrast={1.15}
      inkColor="#120f17" paperColor="#f4f1ea"
      revealRadius={200} softness={0.6} linger={1}
      clickBurst />
  </div>;
}
