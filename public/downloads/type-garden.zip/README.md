# Type Garden

A React botanical typography playground and poster editor.
Flower geometry, animation, and export code are original. No proprietary reference source is included.
Bodoni Moda is an open-licensed font substitute, distributed with its SIL Open Font License.

## Install
Copy TypeGarden.jsx, TypeGarden.css, and the adjacent type-garden font folder into your React 18+ app.
Keep the relative paths intact. There are no additional npm dependencies. The drawing engine uses
Canvas 2D and Path2D, with ResizeObserver/IntersectionObserver and standard browser font APIs.
Type mode supports desktop input, paste, mobile keyboards, and composition events.

## Interaction
Click the canvas and type to grow. Letters re-center smoothly; stems trace first, then leaves
unfold, buds open with a settling overshoot, and fine petal lines draw in. Spaces cut connecting
vines; Backspace retracts and folds the deleted plant;
Enter clears Type mode. Poster mode has its own editable words, Regrow, seven loop presets,
and ten palettes. The whole design fits its container. Poster controls move below the canvas
on narrow containers. Input is scoped: this component does not intercept document-wide keys.

## Props
initialText="": words on mount. Poster uses "in bloom" when empty initially.
initialMode="type": "type" or "poster".
initialPalette="Rose noir": one of the ten palette names exported as gardenPalettes.
initialMotion="breathe": breathe, grow, typed, gust, reach, scatter, visitor.
height=720: number (400–1200px) or CSS value such as "100svh".
fontSize=240: maximum type size (60–360px); posters use 80% in their 1080px design space.
density=1: secondary bloom density (0–2); zero keeps the main flowers.
seed=23: deterministic geometry seed (0–999999).
maxLength=80: grapheme limit (1–160).
exportSize=1080: square poster export size (256–1080px). Type stills use the stage size.
exportFps=30: animation export frame rate (6–30).
autoFocus=false: focus the typing input on mount; avoid stealing focus in larger pages.
onTextChange(text): user edit/clear callback.
onExport({format,blob}): called after downloading an export; not called for clipboard copy.
className="": additional root class.
Initial props are read on mount; remount to reset the editor. Size/density/seed props update live.

## Exports
All rendering and encoding happen locally in the browser. PNG captures a still; SVG embeds the font
and vector paths. Clipboard copies the SVG code (secure context and clipboard permission required).
Poster PNG frames are numbered and stored in a ZIP without an external archive library.
Video uses MediaRecorder and canvas.captureStream: MP4 if supported, otherwise explicitly labeled
WebM. When video is unavailable, export PNG frames instead. Video records in real time; keep the
page visible until it finishes. Progress and cancellation are provided. Lower resolution/frame rate
reduces ZIP size and memory use. The component does not promise sample-accurate video timestamps;
browser encoding and scheduling can affect the resulting container frame rate.

Reduced motion makes the live artwork static, while explicitly requested animation exports remain
animated. Offscreen/hidden-tab live rendering pauses. No simulated user presence, donation UI,
collaboration backend, external image service, or analytics is included.

Next.js App Router supports the use client directive. With Pages Router, move the stylesheet import
to pages/_app.jsx. Retain the font directory and font license when redistributing.
