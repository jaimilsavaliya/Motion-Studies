import TypeGarden from './components/TypeGarden';

export default function ArtPlayground() {
  return <TypeGarden
    height={720}
    initialText={""}
    initialMode={"type"}
    initialPalette={"Rose noir"}
    initialMotion={"breathe"}
    fontSize={240}
    density={1}
    seed={23}
    maxLength={80}
    exportSize={1080}
    exportFps={30}
  />;
}
