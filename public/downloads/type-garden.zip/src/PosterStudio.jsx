import TypeGarden from './components/TypeGarden';

export default function PosterStudio() {
  return <TypeGarden
    height="100svh"
    initialMode="poster"
    initialText="in bloom"
    initialPalette="Paper"
    initialMotion="visitor"
    exportSize={1080}
    exportFps={30}
    onTextChange={text => console.log('Garden words:', text)}
    onExport={({ format, blob }) => {
      console.log(format, blob.size, 'bytes, generated locally');
    }}
  />;
}
