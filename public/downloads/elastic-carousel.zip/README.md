# Elastic Carousel

Independent React + WebGL implementation inspired by https://useplanes.com/components/elastic-carousel.
No proprietary Planes source or shaders are included. The renderer and shaders here are original.

Copy ElasticCarousel.jsx and ElasticCarousel.css into the same directory in your React 18+ project.
No Three.js, carousel framework, or animation package is required.
Modern browsers need ResizeObserver, IntersectionObserver, pointer capture, and WebGL for full effects.
A DOM-based gallery remains available without WebGL or after a texture/context failure.

Supply your own appropriately licensed images. Demo imagery is not included in the archive.
Local images work directly; remote texture images must allow anonymous cross-origin access.

## Props
items: array of { src, title, alt? }; default []. Images are center-cropped.
height: 560px; clamped 280–800, scaled to 60% below 640px container width.
stretch: 1; clamped 0–2. Zero disables the mesh deformation.
blur: 1; clamped 0–2. Zero disables directional motion blur.
gap: 16px; clamped 4–40, scaled down on mobile.
intro: true; left-to-right thumbnail scale/fade, a held strip, then blurred expansion. False starts expanded.
initialIndex: middle item by default; clamped to the collection, read on mount.
pixelRatio: 1.5; clamped .5–2, capped at device DPR.
showControls: true; Previous/Next controls and a short hint.
onIndexChange: optional (index, item) callback as the centered image changes.
onOpenChange: optional (open) callback for the isolated-image state.
className: optional root class.

Drag horizontally, release to snap to the nearest image. Selection loops. Click an off-center image
to select it; click the centered image to isolate it. Close or Escape returns to the reel.
This is an in-place state, not a modal or page navigation. No timed slide autoplay is used.
Keyboard: Left/Right browse; Enter/Space on the stage toggles the isolated view.
Vertical touch and wheel scrolling remain available.
Reduced motion skips the entrance, smoothing, and velocity effects.
Idle, offscreen, and hidden-tab rendering stops. Context loss uses the simpler DOM fallback;
restoration rebuilds the WebGL renderer. Failed images have a named placeholder.

Next.js App Router supports the included use client directive. With Pages Router, move the CSS import
to pages/_app.jsx.
