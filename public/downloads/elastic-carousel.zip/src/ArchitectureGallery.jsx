import ElasticCarousel from './components/ElasticCarousel';

export default function ArchitectureGallery() {
  return (
    <ElasticCarousel
      items={[
        { src: '/work/atrium.webp', title: 'Atrium', alt: 'Light-filled atrium' },
        { src: '/work/stairwell.webp', title: 'Stairwell', alt: 'A curved concrete stair' },
        { src: '/work/courtyard.webp', title: 'Courtyard', alt: 'An enclosed garden' },
      ]}
      height={520}
      stretch={0.5}
      blur={0}
      intro={false}
      initialIndex={0}
      pixelRatio={1}
    />
  );
}
