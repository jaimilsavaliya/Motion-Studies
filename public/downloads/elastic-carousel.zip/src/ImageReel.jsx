import ElasticCarousel from './components/ElasticCarousel';

const items = [
  { src: '/gallery/1.webp', title: 'Ferris Wheel', alt: 'Ferris wheel at golden hour' },
  { src: '/gallery/2.webp', title: 'Stingrays', alt: 'Stingrays in turquoise water' },
  { src: '/gallery/3.webp', title: 'Forest Stream', alt: 'A stream through a mossy forest' },
  { src: '/gallery/4.webp', title: 'Kitesurfer', alt: 'Kitesurfer crossing the bay' },
  { src: '/gallery/5.webp', title: 'Phone Booth', alt: 'A phone booth on a beach' },
  { src: '/gallery/6.webp', title: 'Golden Hour', alt: 'Evening light over the coast' },
  { src: '/gallery/7.webp', title: 'The Cove', alt: 'Boat anchored in a clear cove' },
  { src: '/gallery/8.webp', title: 'Sunset Cliff', alt: 'Sun setting behind a sea cliff' },
];

export default function ImageReel() {
  return (
    <ElasticCarousel
      items={items}
      height={560}
      stretch={1}
      blur={1}
      gap={16}
      intro={true}
      initialIndex={3}
      pixelRatio={1.5}
    />
  );
}
