# Hover Members

Independent React implementation. Requires React 18+, a CSS-aware bundler, Web Animations,
ResizeObserver, CSS container queries/units and modern Pointer Events. No motion packages.
Copy HoverMembers.jsx, HoverMembers.css and the entire hover-members/ font directory.
Thunder Black LC is included unmodified. Its original License.pdf permits personal and
commercial project use, prohibits modifying the font without the designer's permission,
and retains all other rights with the designer. Retain this license with the font.
Demo imagery is excluded. Supply your own appropriately licensed portraits.

## API
teamMembers: [] by default; each member has name and image, optional id and objectPosition.
Additional metadata is passed through to callbacks. Use stable ids when reordering data.
defaultName: OUR TEAM. Short headings work best; long text shrinks to fit.
height: 720px; numbers clamp to 320–1200, or supply a definite CSS height such as 100svh.
backgroundColor: #121212. textColor: #ffffff. hoverTextColor and cursorColor: #fb2c36.
showCursor: true. Pointer follower is hidden for touch and reduced motion.
onActiveChange(index, member): called on interaction changes, not initial mount.
  Both arguments are null when returning to the default heading.
onMemberSelect(index, member): click/tap/Enter/Space callback; no automatic navigation.
aria-label: Team members. className: optional additional root class.
Override the CSS custom property --hm-font-family to use another licensed typeface.

Portraits occupy 60px squares and grow to 120px over 200ms, reflowing their neighbors.
The portrait strip sits at 10% of stage height; it wraps on small containers.
Type is 28% of container width inside a 22%-wide-height clipping window, with long names fitted.
The center letter starts first (right-hand center for even lengths); each outward step
waits 55ms. Letter travel is 800ms with cubic-bezier(.19,1,.22,1).
The default heading exits upward. Member names arrive from below and exit downward.
Interrupted transitions continue from their current pose; only three visual layers are retained.
A 120px circle follows the pointer with a time-based lag and top-left anchoring.

Tab/focus reveals names. Arrow/Home/End keys browse members. Enter/Space activate callbacks.
Escape restores the heading. Touch taps toggle a member; tapping the blank background resets.
Reduced motion snaps lettering/portrait size and hides the follower. Missing images show
initials, empty arrays retain the default heading, and a single live heading exposes the
current text to assistive technology. Animated duplicates are aria-hidden.

The use client directive supports Next.js App Router. For Pages Router, move the CSS
import to pages/_app.jsx. Keep the font folder beside the stylesheet.
