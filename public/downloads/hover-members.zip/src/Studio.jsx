import { useState } from 'react';
import HoverMembers from './components/HoverMembers';

export default function Studio({ teamMembers }) {
  const [selected, setSelected] = useState(null);
  return <>
    <HoverMembers teamMembers={teamMembers} defaultName="OUR TEAM"
      height="85svh" backgroundColor="#eeeae2" textColor="#161616"
      hoverTextColor="#6c37f2" cursorColor="#6c37f2"
      onMemberSelect={(index, member) => setSelected(member)} />
    {selected && <p>{selected.name} — {selected.role}</p>}
  </>;
}
