import HoverMembers from './components/HoverMembers';

const teamMembers = [
  { id: 'alex', name: 'Alex', image: '/team/alex.webp' },
  { id: 'jules', name: 'Jules', image: '/team/jules.webp' },
  { id: 'sam', name: 'Sam', image: '/team/sam.webp' },
];

export default function Team() {
  return <HoverMembers teamMembers={teamMembers}
    defaultName="OUR TEAM" height={720}
    backgroundColor="#121212" textColor="#ffffff"
    hoverTextColor="#fb2c36" cursorColor="#fb2c36"
    showCursor={true} />;
}
