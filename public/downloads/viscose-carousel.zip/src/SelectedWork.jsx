'use client';

import ViscoseCarousel from './components/ViscoseCarousel';
import './components/ViscoseCarousel.css';

// Copy the adjacent viscose-carousel/ring and viscose-carousel/shaders
// directories, then keep the component as a dedicated full-viewport route.
export default function SelectedWork() {
  return <ViscoseCarousel />;
}
