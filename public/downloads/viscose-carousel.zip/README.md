# Viscose Carousel

This archive integrates the original **Viscose Carousel** source by **Yousuf Soomro**.
Copyright © 2026 Yousuf Soomro. It is released under the MIT License; retain the included
`licenses/Viscose-MIT-LICENSE.txt` and `THIRD_PARTY_NOTICES.md` when redistributing.

- Upstream: https://github.com/Yousuf-developer/Viscose-carousel
- Integration changes: Vite-compatible imports, component-scoped stage CSS, system-font
defaults, locally generated replacement art, and a reduced backing resolution only when a
software WebGL renderer is detected.

## Important asset boundary

The upstream MIT license covers source code, not the upstream `public/` files. This archive
**does not include** upstream project imagery, video, PP Neue Montreal, Satoshi, or Geist files.
`public/viscose-original/` instead contains original local placeholder WebP artwork generated for
this integration. Replace it with your own appropriately licensed art before production use.

## Install

```sh
npm install three gsap lil-gui
```

Copy the complete `src/components/` subtree and `public/viscose-original/` folder in this archive.
Do not separate `ViscoseCarousel.jsx` from its `viscose-carousel/ring/` or
`viscose-carousel/shaders/` directories: they are source imports, not optional examples.

Render `<ViscoseCarousel />` on a dedicated full-viewport route. The original source owns a
fixed stage and opens project stories as a scrollable layer over its ring; it is deliberately
not a prop-configured inline carousel.

```jsx
'use client';

import ViscoseCarousel from './components/ViscoseCarousel';
import './components/ViscoseCarousel.css';

export default function SelectedWork() {
  return <ViscoseCarousel />;
}
```

## Customise project content

Edit `src/components/viscose-carousel/ring/projects.js` and replace the records, project copy,
media rows, insight rows, and matching local files. Card images are loaded from
`/viscose-original/`; phone-sized copies are read from `/viscose-original/sm/`.

The renderer uses Three.js, GLSL, and GSAP. It starts from one seed card, waits for its atlas,
forms a looping ring, responds to drag/wheel input, and expands a selected front card into an
editorial project view. In a Vite development build, append `?gui=1` to the route or press `G`
to open the upstream tuning panel. The dynamic dev panel is omitted from production builds.

## Performance and compatibility

WebGL is required for the intended visual result. The upstream device-pixel-ratio cap is retained
on hardware-rendered browsers. A software renderer is detected and gets a reduced backing store
so the original entrance remains responsive in remote previews and virtual machines. Use
compressed local images in real projects; the atlas and open-page textures are sized from the
viewport and GPU texture limits.

## Notices

`shaders/planeShaders.js` retains the included simplex-noise notice for Ashima Arts and Stefan
Gustavson under MIT. See `THIRD_PARTY_NOTICES.md` for the complete provenance and asset boundary.
