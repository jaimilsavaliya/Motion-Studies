import ShutterGallery from './components/ShutterGallery';

const items = [
  { src: '/images/car-1.jpg', alt: 'Red sports car in a dark studio',
    title: 'Crimson Edge', subtitle: 'Front three-quarter, studio black' },
  { src: '/images/car-2.jpg', alt: 'Round red tail lamps on black bodywork',
    title: 'Twin Embers', subtitle: 'Round tail lamps, gloss black' },
  { src: '/images/car-3.jpg', alt: 'A red coupe on a city street at night',
    title: 'Night Run', subtitle: 'Rear three-quarter, 2:14 AM' },
];

export default function Collection() {
  return <ShutterGallery items={items} height={520}
    gap={12} expandedGrow={12.6} defaultOpen={null} />;
}
