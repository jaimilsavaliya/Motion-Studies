import { useState } from 'react';
import ShutterGallery from './components/ShutterGallery';

export default function ProjectGallery({ projects }) {
  const [open, setOpen] = useState(null);
  return <>
    <ShutterGallery items={projects} height={480}
      open={open} onOpenChange={setOpen} aria-label="Selected projects" />
    <button onClick={() => setOpen(null)} disabled={open === null}>
      Close image
    </button>
    <p aria-live="polite">{open === null ? 'Choose a project' : projects[open]?.title}</p>
  </>;
}
