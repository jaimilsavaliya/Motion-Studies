# Shutter Gallery

Independent React + CSS implementation. No proprietary component source or animation library.
Copy src/components/ShutterGallery.jsx and ShutterGallery.css into your React 18+ application.
Replace the example image paths with your own appropriately licensed images. Demo photos are excluded.
Requires modern CSS container query units, ResizeObserver, and CSS individual transforms.

## API
items: array of {src, alt, title?, subtitle?, objectPosition?}; default [].
height: 480px (clamped 240–1000); demo uses 520px.
gap: 12px (clamped 0–32), halved below 576px container width.
expandedGrow: 12.6 (clamped 2–24); other panels have flex weight 1.
defaultOpen: null or zero-based initial index, read on mount.
open: controlled zero-based index or null. Omit for uncontrolled behavior.
onOpenChange: optional callback receiving a requested index or null.
aria-label: accessible group name, default Image gallery.
className: optional additional root class.
Invalid indices render all shutters closed. Empty collections and failed images have fallbacks.

Hover/focus peeks; click, Enter, or Space toggles a panel. Escape closes without moving focus.
Tab visits every shutter. Arrow keys follow the layout; Home/End focus the first/last panel.
Touch opens on the first tap without a sticky hover. Controlled parents must update open.
The image stays gallery-sized behind each panel, with an independent 1.08-to-1 unzoom.
Below 576px container width (not viewport width), the strip becomes vertical.
Reduced motion snaps layout, shade and image; captions use a short opacity-only fade.
No autoplay, scrolling interception, remote runtime assets or animation dependencies.

The use client directive supports Next.js App Router. For Pages Router, move the CSS import
into pages/_app.jsx. Keep these files together when using Vite or other CSS-aware bundlers.
