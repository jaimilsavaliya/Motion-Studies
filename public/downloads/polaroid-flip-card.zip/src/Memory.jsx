import PolaroidFlipCard from './components/PolaroidFlipCard';

export default function Memory() {
  return <PolaroidFlipCard
    src="/photos/sakura.jpg"
    alt="Cherry blossoms in bloom"
    caption="04/02/25"
    message={"kyoto, april.\ni got up before the crowds\nand had the whole path to myself.\npetals everywhere, no one around.\nbest morning of the trip."}
    width={340} rotation={-3} tilt={14} duration={760}
    theme="dark" defaultFlipped={false}
  />;
}
