import { useState } from 'react';
import PolaroidFlipCard from './components/PolaroidFlipCard';

export default function GuestNote() {
  const [flipped, setFlipped] = useState(false);
  return <>
    <PolaroidFlipCard src="/photos/together.jpg"
      alt="A couple walking along the shore" caption="06/14/26"
      message={"We are so glad you are here.\nThank you for being part of our story."}
      theme="light" rotation={2}
      flipped={flipped} onFlipChange={setFlipped} />
    <button onClick={() => setFlipped(value => !value)}>
      {flipped ? 'See the photograph' : 'Read our note'}
    </button>
  </>;
}
