# Polaroid Flip Card

Independent React + CSS implementation; no proprietary component source or animation library.
Requires React 18+, CSS imports, modern 3D transforms and container query units.

Copy src/components/PolaroidFlipCard.jsx, PolaroidFlipCard.css and the entire
polaroid-flip-card/ font folder into your project. Keep Caveat.ttf and OFL.txt together.
Caveat is bundled under the SIL Open Font License. Retain the license when redistributing.
Demo photos are excluded; replace example image paths with your own licensed photography.

## Props
src: photograph URL. alt: descriptive text, default Photograph.
caption: short front caption. message: reverse note, preserving newlines. Both default empty.
width: 340px, clamped 160–640; max-width 100% of the container.
rotation: -3 degrees on the front, clamped -20–20; the reverse turns upright.
tilt: 14 degrees maximum horizontal pointer tilt (0–24), vertical tilt at 80%.
duration: 760ms for the flip, clamped 200–1600; pointer/outer rotation have separate timing.
theme: dark (default) or light. objectPosition: center (CSS object-position).
defaultFlipped: false, read on mount. flipped: optional controlled boolean.
onFlipChange: optional callback with the requested boolean; controlled parents must update flipped.
className: additional root class.

Click/tap, Enter, or Space toggles. Escape returns to the photograph. Hover only tilts/lifts;
it does not flip. Pointer exit resets tilt, highlight, and lift; touch has no sticky hover.
The button exposes aria-pressed and the note describes it on the reverse. Faces are hidden
from assistive technology when inactive. Long notes scroll, but short notes work best.
Reduced motion snaps sides and disables pointer tilt/lift/glare. No autoplay.
Leave room around the card for rotation and the small mid-flip enlargement.
The animation loop runs only while turning, cancels on unmount, and reverses from its current angle.
The photo has a fallback for failed loads. No remote font or media request is built into the component.

Next.js App Router supports the use client directive. For Pages Router, move the CSS import
into pages/_app.jsx. Keep the font directory relative to the stylesheet.
