# Tik Tik Color List

Independent React + CSS implementation. React 18+, CSS imports, ResizeObserver,
container queries and Pointer Events are required. No animation package or gated registry.
Copy TikTikColorList.jsx and .css plus the entire tik-tik-color-list/ font folder.
The bundled Inter font is under the SIL Open Font License; retain OFL.txt when redistributing.
Demo posters and sound are excluded. Add your own appropriately licensed media.

## API
projects: array of {id, name, badge, bgColor, image}; default [].
Optional project fields: date (default 01 sep), description (metadata), alt, objectPosition.
height: 720; numeric values clamp to 320–1200px, or supply CSS such as 100svh.
showPreview: true; previewSize: lg (400px), md (320px), sm (240px).
enableSound: false. With true, click or press a key inside the stage to unlock Web Audio.
soundSrc: optional licensed audio URL. Omit it to use a synthesized tick.
infiniteScroll: true; scrollThreshold: 1000px, bounded to one cycle and 0–5000px.
onActiveChange(index, project): active-project callback, including initial selection.
onSelect(index, project): row activation callback; no navigation is performed internally.
aria-label: Project archive. className: additional root class.

The stage owns its native scroll container. Down-scroll entry is at 70% of stage height;
up-scroll entry is at 65%, retaining the current selection until a boundary is crossed.
Repeated rows are bounded and recentered near edges. Finite mode adds leading/trailing
space so every row can be selected. One-item arrays automatically use finite mode.
The first visible row in infinite mode is the first project, while selection is at the
70% guide; the initially active item therefore depends on stage height.

Desktop type is 72px with 112px row cadence; below 768px container width it is 36px/80px.
The image and dates are hidden below 768px. The preview sits 40px from bottom/right.
Images switch in place; the preview position persists across selections.
Drag follows the pointer and coasts with exponential momentum. It is unconstrained;
Escape anywhere inside the stage or double-click restores the image to its corner.
Focus the image and use arrow keys to reposition it, Enter/Space to reset.
Arrow/Home/End/Page keys in the list navigate projects. Repeated copies are hidden
from assistive technology; the active collection cycle remains accessible.
Reduced motion disables fades, smooth scrolling and release momentum.
Empty arrays and image failures have visible fallbacks. Audio failures are non-blocking.
Choose background colors that maintain sufficient contrast with black text.

The use client directive supports Next.js App Router. For Pages Router, move the CSS
import into pages/_app.jsx. Keep the font directory relative to the stylesheet.
