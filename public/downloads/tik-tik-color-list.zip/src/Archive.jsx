import TikTikColorList from './components/TikTikColorList';

const projects = [
  { id: 0, name: 'Aarzoo', badge: 'Print Design', date: '01 sep',
    bgColor: '#ff0000', image: '/images/aarzoo.webp' },
  { id: 1, name: 'Lost Horizons', badge: 'Concept Art', date: '01 sep',
    bgColor: '#ffffff', image: '/images/horizons.webp' },
  { id: 2, name: 'Eternal Echoes', badge: 'Typography', date: '01 sep',
    bgColor: '#8b5cf6', image: '/images/echoes.webp' },
];

export default function Archive() {
  return <TikTikColorList projects={projects} height={720}
    showPreview={true} previewSize="lg" enableSound={false}
    infiniteScroll={true} scrollThreshold={1000} />;
}
