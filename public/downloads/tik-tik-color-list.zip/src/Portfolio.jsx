import { useState } from 'react';
import TikTikColorList from './components/TikTikColorList';

export default function Portfolio({ projects }) {
  const [sound, setSound] = useState(false);
  return <>
    <button onClick={() => setSound(value => !value)}>
      {sound ? 'Disable sound' : 'Enable sound on next interaction'}
    </button>
    <TikTikColorList projects={projects} height="85svh"
      enableSound={sound} previewSize="md"
      onActiveChange={(index, project) => console.log(project.name)}
      onSelect={(index, project) => console.log('Open project:', project.id)} />
  </>;
}
